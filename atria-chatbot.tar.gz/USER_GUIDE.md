# AI Chat Application - User Guide

Welcome to the AI Chat Application! This comprehensive guide will help you understand all features and get the most out of the platform.

## Table of Contents

1. [Getting Started](#getting-started)
2. [Features Overview](#features-overview)
3. [User Interface Guide](#user-interface-guide)
4. [Admin Features](#admin-features)
5. [Dark Mode](#dark-mode)
6. [Benefits and Advantages](#benefits-and-advantages)
7. [Best Practices](#best-practices)
8. [FAQ](#faq)

---

## Getting Started

### Creating an Account

1. Navigate to the login page
2. Click "Don't have an account? Sign up"
3. Enter your email address and a secure password
4. Click "Sign Up"
5. You'll be automatically logged in and redirected to the chat interface

**Note:** Email confirmation is not required. Your account is ready to use immediately.

### Logging In

1. Enter your registered email and password
2. Click "Sign In"
3. You'll be redirected to the chat interface

### First Steps

After logging in, you'll see:
- The chat interface with an empty message area
- An input field at the bottom to type messages
- Your email displayed in the header
- A logout button
- A theme toggle button (moon/sun icon)

---

## Features Overview

### Core Features

1. **AI-Powered Chat**
   - Send messages and receive intelligent AI responses
   - Message history is automatically saved
   - Conversations persist across sessions

2. **User Authentication**
   - Secure login and registration
   - Session management
   - Protected routes

3. **Dark Mode**
   - Toggle between light and dark themes
   - Automatic theme persistence
   - Eye-friendly dark blue color scheme (#252440)

4. **Admin Dashboard** (Admin users only)
   - View all registered users
   - Access audit logs
   - Manage user roles

5. **Role Management** (Admin users only)
   - Promote users to admin
   - Demote admins to regular users
   - Fine-grained access control

---

## User Interface Guide

### Chat Interface

#### Main Elements

**Header:**
- **Title:** "AI Chat"
- **Email:** Your registered email address
- **Admin Button:** (Admin only) Access to admin dashboard
- **Theme Toggle:** Switch between light and dark mode
- **Logout Button:** Sign out of your account

**Chat Area:**
- **Your Messages:** Displayed on the right in dark blue bubbles
- **AI Responses:** Displayed on the left in white/dark bubbles
- **Empty State:** Shows a user icon and prompt when no messages exist

**Input Area:**
- **Text Field:** Type your messages here
- **Send Button:** Click to send or press Enter
- **Loading State:** Button shows "Sending..." while processing

#### Sending Messages

1. Type your message in the input field
2. Press Enter or click the send button
3. Your message appears immediately
4. Wait for the AI response (appears below your message)
5. A success notification confirms the message was sent

#### Message History

- All your previous conversations are automatically loaded
- Messages are displayed in chronological order
- The view automatically scrolls to the latest message
- Message history persists even after logout

---

## Admin Features

### Accessing Admin Dashboard

**Requirements:**
- Your account must have the 'admin' role
- Only admins can promote other users to admin

**Access:**
1. Look for the "Admin" button in the chat header
2. Click to navigate to the admin dashboard

### Admin Dashboard Overview

#### Users Section

View all registered users with:
- **Email address**
- **Role badge** (Admin or User)
- **Registration date**

The table is color-coded:
- Admin users: Blue badge
- Regular users: Gray badge

#### Audit Logs Section

Monitor system activity with:
- **User ID:** Identifies who performed the action
- **Action:** Description of what was done
- **Timestamp:** When the action occurred

Shows the 100 most recent logs in reverse chronological order.

### Admin Settings

#### Accessing Settings

1. From the admin dashboard, click "Settings" button
2. You'll see the User Role Management page

#### Managing User Roles

**Promote to Admin:**
1. Find a user with "user" role
2. Click "Promote to Admin" button
3. Confirm the action
4. User now has admin privileges

**Demote to User:**
1. Find a user with "admin" role
2. Click "Demote to User" button
3. Confirm the action
4. User loses admin privileges

**Important Notes:**
- You cannot change your own role (safety feature)
- Role changes take effect immediately
- Demoted admins lose access to admin features instantly

---

## Dark Mode

### What is Dark Mode?

Dark mode transforms the interface with:
- Dark blue backgrounds (#252440)
- Light text for easy reading
- Reduced eye strain in low-light environments
- Modern, professional appearance

### How to Enable Dark Mode

1. **On Any Page:** Look for the moon icon button
2. **Click Once:** Interface switches to dark theme
3. **Automatic Save:** Your preference is remembered

### How to Disable Dark Mode

1. Look for the sun icon button
2. Click once to return to light theme
3. Preference is saved automatically

### Dark Mode Features

- **Persistent:** Stays active across sessions
- **Universal:** Works on all pages (login, chat, admin)
- **Smooth Transitions:** Color changes are animated
- **High Contrast:** Text remains readable
- **Professional Colors:** Uses elegant dark blue palette

---

## Benefits and Advantages

### For End Users

#### 1. Instant Access
- **No Email Verification:** Start using immediately after signup
- **Fast Login:** Quick authentication process
- **Auto-Save:** Never lose your conversation history

#### 2. User-Friendly Interface
- **Clean Design:** Distraction-free chat experience
- **Intuitive Controls:** Easy to learn and use
- **Responsive:** Works on desktop, tablet, and mobile
- **Smooth Animations:** Polished, professional feel

#### 3. Personalization
- **Dark Mode:** Choose your preferred theme
- **Persistent Settings:** Preferences saved automatically
- **Message History:** Access all past conversations

#### 4. Security
- **Secure Authentication:** Protected with industry-standard security
- **Data Privacy:** Row-level security ensures data isolation
- **Session Management:** Automatic logout protection

#### 5. Reliability
- **Database Backup:** Messages stored in Supabase
- **Error Handling:** Graceful error messages
- **Stable Performance:** Built with modern, tested technologies

### For Administrators

#### 1. Complete Control
- **User Management:** View all registered users
- **Role Assignment:** Grant or revoke admin privileges
- **Activity Monitoring:** Track system usage via audit logs

#### 2. Security Features
- **Access Control:** Restrict admin features to authorized users
- **Audit Trail:** Complete log of all actions
- **Self-Protection:** Cannot accidentally remove own admin role

#### 3. Easy Administration
- **Visual Interface:** No database access needed
- **One-Click Actions:** Simple role management
- **Real-Time Updates:** Changes reflect immediately

#### 4. Monitoring Capabilities
- **User Activity:** Track message sending and system usage
- **Audit Logs:** Review recent system events
- **User Growth:** Monitor new registrations

### For Organizations

#### 1. Scalability
- **Supabase Backend:** Enterprise-grade database
- **Modern Stack:** Built with React and TypeScript
- **Cloud-Native:** Easy to deploy and scale

#### 2. Extensibility
- **AI Integration:** Connect to any AI API
- **Webhook Support:** Integrate with n8n or other tools
- **Modular Design:** Easy to add new features

#### 3. Cost-Effective
- **Open Source Stack:** No licensing fees
- **Efficient Database:** Supabase free tier available
- **Low Maintenance:** Minimal operational overhead

#### 4. Professional Quality
- **Production-Ready:** Built with best practices
- **Type Safety:** TypeScript prevents common bugs
- **Tested Components:** Reliable, stable codebase

### Technical Advantages

#### 1. Modern Technology Stack
- **React 18:** Latest UI framework
- **TypeScript:** Type-safe development
- **Vite:** Fast build and development
- **Tailwind CSS:** Utility-first styling
- **Supabase:** PostgreSQL database with real-time features

#### 2. Security Best Practices
- **Row Level Security (RLS):** Database-level protection
- **Secure Authentication:** Built on Supabase Auth
- **Protected Routes:** Client-side route guards
- **XSS Prevention:** React's built-in protections

#### 3. Performance Optimizations
- **Fast Loading:** Optimized bundle size
- **Efficient Queries:** Database query optimization
- **Lazy Loading:** Components loaded on demand
- **Smooth Animations:** GPU-accelerated transitions

#### 4. Developer Experience
- **Clean Code:** Well-organized file structure
- **Type Safety:** Catch errors during development
- **Hot Reload:** Instant feedback during development
- **Documented:** Clear code comments and documentation

---

## Best Practices

### For Users

1. **Use Strong Passwords:** Choose a secure password with mixed characters
2. **Logout on Shared Devices:** Always logout when using public computers
3. **Clear Messages:** Write clear, specific questions for better AI responses
4. **Check History:** Review past conversations before asking repeated questions

### For Administrators

1. **Regular Monitoring:** Check audit logs periodically
2. **Careful Promotion:** Only grant admin to trusted users
3. **Document Decisions:** Keep records of role changes
4. **Test Changes:** Verify role changes work as expected

### For Developers

1. **Environment Variables:** Never commit `.env` files
2. **Database Backups:** Regular Supabase project backups
3. **RLS Testing:** Verify security policies work correctly
4. **Error Monitoring:** Set up error tracking in production

---

## FAQ

### General Questions

**Q: Is email confirmation required?**
A: No, accounts are ready to use immediately after signup.

**Q: Can I delete my messages?**
A: Currently, messages are permanent. This feature may be added in the future.

**Q: How long are messages stored?**
A: Messages are stored indefinitely in the database.

**Q: Can I export my chat history?**
A: Not currently, but this feature is planned for future releases.

### Account Questions

**Q: I forgot my password. How do I reset it?**
A: Password reset is handled through Supabase. Contact your admin or check Supabase documentation.

**Q: Can I change my email?**
A: Currently, email changes must be done through Supabase dashboard.

**Q: How do I delete my account?**
A: Contact an administrator to remove your account.

### Dark Mode Questions

**Q: Does dark mode save battery on my device?**
A: On OLED screens, dark mode can help save battery life.

**Q: Can I schedule dark mode based on time?**
A: Not currently, but you can toggle it manually at any time.

**Q: Why does the theme reset sometimes?**
A: Clear browser cache or check localStorage settings if theme doesn't persist.

### Admin Questions

**Q: How do I become an admin?**
A: An existing admin must promote you, or manually set role in Supabase dashboard.

**Q: Can there be multiple admins?**
A: Yes, unlimited admins are supported.

**Q: What happens if I'm the only admin?**
A: Be careful not to demote yourself. If all admins are removed, database access is required to fix.

**Q: Can I see other users' messages?**
A: No, even admins cannot see other users' messages (RLS protection).

### Technical Questions

**Q: What browser is recommended?**
A: Modern browsers: Chrome, Firefox, Safari, or Edge (latest versions).

**Q: Does it work offline?**
A: No, an internet connection is required for all features.

**Q: Is my data secure?**
A: Yes, all data is protected with row-level security and encrypted connections.

**Q: Can I self-host this application?**
A: Yes, it's designed to be deployed anywhere that supports Vite applications.

---

## Support

For additional help or questions:
1. Review the testing documentation (TESTING.md)
2. Check the Supabase dashboard for database issues
3. Review browser console for error messages
4. Contact your system administrator

---

## Conclusion

This AI Chat application combines modern technology with user-friendly design to provide a secure, efficient, and pleasant chat experience. Whether you're a regular user enjoying conversations or an admin managing the system, the intuitive interface and powerful features make it easy to accomplish your goals.

Enjoy using the application!
