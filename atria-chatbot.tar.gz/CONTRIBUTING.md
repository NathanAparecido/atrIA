# Guia de Contribuição

Obrigado por considerar contribuir para o AtrIA Chatbot! Este documento fornece diretrizes para garantir um processo de contribuição tranquilo e eficiente.

## 📋 Código de Conduta

- Seja respeitoso e construtivo
- Aceite feedback com abertura
- Foque no que é melhor para a comunidade
- Mantenha discussões profissionais e no tópico

## 🚀 Como Posso Contribuir?

### Reportando Bugs

Antes de criar um relatório de bug:
1. Verifique se o bug já não foi reportado nas [Issues](https://github.com/SEU_USUARIO/atria-chatbot/issues)
2. Determine qual repositório o problema deve ser reportado
3. Colete informações sobre o bug

**Como escrever um bom relatório de bug:**

```markdown
**Descrição do Bug**
Uma descrição clara e concisa do problema.

**Passos para Reproduzir**
1. Vá para '...'
2. Clique em '...'
3. Role até '...'
4. Veja o erro

**Comportamento Esperado**
Uma descrição clara do que você esperava que acontecesse.

**Comportamento Atual**
Uma descrição do que realmente aconteceu.

**Screenshots**
Se aplicável, adicione screenshots para ajudar a explicar o problema.

**Ambiente:**
 - OS: [ex: Windows 11]
 - Navegador: [ex: Chrome 120]
 - Versão do Node: [ex: 18.17.0]
```

### Sugerindo Melhorias

Antes de criar uma sugestão:
1. Verifique se já não existe uma sugestão similar
2. Determine se sua sugestão se encaixa no escopo do projeto
3. Forneça o máximo de detalhes possível

**Template para sugestões:**

```markdown
**O problema relacionado**
Uma descrição clara do problema. Ex: Sempre fico frustrado quando [...]

**A solução que você gostaria**
Uma descrição clara do que você quer que aconteça.

**Alternativas consideradas**
Uma descrição de qualquer solução ou recurso alternativo que você considerou.

**Contexto adicional**
Adicione qualquer outro contexto ou screenshots sobre a sugestão aqui.
```

### Contribuindo com Código

#### Processo de Pull Request

1. **Fork o Repositório**
   ```bash
   # Clique em "Fork" no GitHub
   git clone https://github.com/SEU_USUARIO/atria-chatbot.git
   cd atria-chatbot
   ```

2. **Configure o Upstream**
   ```bash
   git remote add upstream https://github.com/USUARIO_ORIGINAL/atria-chatbot.git
   ```

3. **Crie uma Branch**
   ```bash
   # Para novas features
   git checkout -b feature/nome-da-feature

   # Para correções de bugs
   git checkout -b fix/nome-do-bug

   # Para documentação
   git checkout -b docs/descricao
   ```

4. **Faça suas Alterações**
   - Siga o estilo de código do projeto
   - Adicione testes se aplicável
   - Atualize a documentação

5. **Commit suas Alterações**
   ```bash
   git add .
   git commit -m "Adiciona: descrição clara da mudança"
   ```

6. **Sincronize com Upstream**
   ```bash
   git fetch upstream
   git rebase upstream/main
   ```

7. **Push para seu Fork**
   ```bash
   git push origin feature/nome-da-feature
   ```

8. **Abra um Pull Request**
   - Vá para o repositório original no GitHub
   - Clique em "New Pull Request"
   - Selecione sua branch
   - Preencha o template de PR

## 💻 Padrões de Código

### TypeScript

- Use TypeScript estrito
- Sempre defina tipos explícitos para funções públicas
- Evite usar `any` - prefira `unknown` quando necessário
- Use interfaces para objetos, types para união/intersecção

```typescript
// ✅ Bom
interface User {
  id: string;
  name: string;
  email: string;
}

function getUser(id: string): Promise<User> {
  // ...
}

// ❌ Evite
function getUser(id) {
  // ...
}
```

### React

- Use componentes funcionais com Hooks
- Nomeie componentes com PascalCase
- Extraia lógica complexa para custom hooks
- Use memo/useMemo/useCallback quando necessário

```typescript
// ✅ Bom
export function UserProfile({ userId }: { userId: string }) {
  const user = useUser(userId);

  return <div>{user.name}</div>;
}

// ❌ Evite
export default ({ userId }) => {
  // ...
}
```

### Estilo CSS (Tailwind)

- Use classes Tailwind quando possível
- Mantenha ordem consistente: layout → espacamento → cores → tipografia
- Extraia classes repetidas para componentes

```tsx
// ✅ Bom
<button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
  Clique aqui
</button>

// ❌ Evite estilos inline diretos
<button style={{ color: 'white', backgroundColor: 'blue' }}>
  Clique aqui
</button>
```

### Mensagens de Commit

Use o padrão de mensagens descritivas:

**Formato:**
```
Tipo: Descrição curta (máximo 50 caracteres)

Descrição detalhada opcional do que e por que (não como).
```

**Tipos:**
- `Adiciona:` - Nova feature
- `Corrige:` - Correção de bug
- `Atualiza:` - Melhoria em feature existente
- `Remove:` - Remoção de código/feature
- `Refatora:` - Mudança de código sem alterar comportamento
- `Documenta:` - Apenas mudanças de documentação
- `Testa:` - Adiciona ou corrige testes
- `Estilo:` - Formatação, ponto e vírgula, etc

**Exemplos:**
```bash
Adiciona: componente de upload de arquivos

Implementa sistema de upload com drag-and-drop,
validação de tipo de arquivo e preview de imagens.

Closes #123
```

```bash
Corrige: erro ao salvar mensagem com caracteres especiais

Adiciona sanitização de entrada antes de salvar no banco.

Fixes #456
```

## 🧪 Testes

Antes de submeter um PR:

```bash
# Verificar tipos TypeScript
npm run typecheck

# Executar linter
npm run lint

# Build de produção
npm run build
```

Se todos os comandos passarem sem erros, seu código está pronto!

## 📚 Documentação

Ao adicionar novas features:
- Atualize o README.md se necessário
- Adicione comentários JSDoc em funções públicas
- Atualize a documentação técnica
- Adicione exemplos de uso

```typescript
/**
 * Busca um usuário pelo ID
 * @param userId - ID único do usuário
 * @returns Objeto com dados do usuário
 * @throws {Error} Se o usuário não for encontrado
 */
export async function getUserById(userId: string): Promise<User> {
  // ...
}
```

## 🏗️ Estrutura de Branches

- `main` - Branch principal (protegida)
- `develop` - Branch de desenvolvimento (se existir)
- `feature/*` - Novas features
- `fix/*` - Correções de bugs
- `docs/*` - Documentação
- `refactor/*` - Refatorações

## ✅ Checklist do Pull Request

Antes de submeter, verifique:

- [ ] O código segue os padrões do projeto
- [ ] Todos os testes passam
- [ ] A documentação foi atualizada
- [ ] Nenhum arquivo sensível foi comitado (.env, etc)
- [ ] Os commits seguem o padrão de mensagens
- [ ] O PR tem descrição clara do que faz
- [ ] Screenshots foram adicionados (se mudança visual)
- [ ] A branch está atualizada com a main

## 🔍 Code Review

Seu PR será revisado por mantenedores. Esteja preparado para:
- Responder perguntas sobre suas escolhas
- Fazer alterações solicitadas
- Discutir abordagens alternativas

**O que esperamos:**
- Código limpo e legível
- Commits atômicos e bem descritos
- Testes quando aplicável
- Documentação atualizada

## 📞 Dúvidas?

- Abra uma [Discussion](https://github.com/SEU_USUARIO/atria-chatbot/discussions)
- Entre em contato por email: suporte@netwise.com.br
- Consulte a [Documentação](GUIA_INSTALACAO_COMPLETO.md)

---

**Obrigado por contribuir!** Cada contribuição, grande ou pequena, é muito apreciada.
