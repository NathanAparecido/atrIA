# Guia Completo de Instalação - AtrIA Chatbot

## Índice

1. [Introdução](#introdução)
2. [Requisitos do Sistema](#requisitos-do-sistema)
3. [Parte 1: Configuração do Ambiente](#parte-1-configuração-do-ambiente)
4. [Parte 2: Configuração do Supabase](#parte-2-configuração-do-supabase)
5. [Parte 3: Instalação do Projeto](#parte-3-instalação-do-projeto)
6. [Parte 4: Configuração do n8n](#parte-4-configuração-do-n8n)
7. [Parte 5: Primeiro Acesso e Testes](#parte-5-primeiro-acesso-e-testes)
8. [Solução de Problemas](#solução-de-problemas)
9. [Manutenção e Atualização](#manutenção-e-atualização)
10. [Trabalhando com GitHub](#trabalhando-com-github)
11. [Próximos Passos](#próximos-passos)

---

## Introdução

Este guia fornece instruções completas e detalhadas para instalar e configurar o AtrIA Chatbot do zero. Siga cada passo cuidadosamente para garantir uma instalação bem-sucedida.

**O que você vai instalar:**
- Frontend em React com TypeScript
- Backend usando Supabase (Database + Auth + Edge Functions)
- Integração com n8n para processamento de mensagens com IA

**Tempo estimado:** 45-60 minutos

---

## Requisitos do Sistema

### Hardware Mínimo
- 4GB de RAM
- 2GB de espaço em disco
- Processador dual-core

### Software Necessário

1. **Node.js (versão 18 ou superior)**
   - Verifique: `node --version`
   - Download: https://nodejs.org/

2. **npm (vem com Node.js)**
   - Verifique: `npm --version`

3. **Git**
   - Verifique: `git --version`
   - Download: https://git-scm.com/

4. **Editor de Código (recomendado)**
   - VS Code: https://code.visualstudio.com/

### Contas Necessárias

1. **Conta Supabase** (gratuita)
   - Registre-se em: https://supabase.com/

2. **Servidor n8n** (configurado e ativo)
   - URL do webhook deve estar disponível

---

## Parte 1: Configuração do Ambiente

### Passo 1.1: Instalação do Node.js

**Windows:**
1. Baixe o instalador em https://nodejs.org/
2. Execute o instalador
3. Siga o assistente de instalação (deixe as opções padrão)
4. Reinicie o computador

**macOS:**
```bash
# Usando Homebrew
brew install node

# Ou baixe o instalador em https://nodejs.org/
```

**Linux (Ubuntu/Debian):**
```bash
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs
```

**Verificação:**
```bash
node --version  # Deve mostrar v18.x.x ou superior
npm --version   # Deve mostrar 9.x.x ou superior
```

### Passo 1.2: Instalação do Git

**Windows:**
1. Baixe em https://git-scm.com/
2. Execute o instalador
3. Use as opções padrão

**macOS:**
```bash
brew install git
```

**Linux:**
```bash
sudo apt-get install git
```

**Verificação:**
```bash
git --version
```

---

## Parte 2: Configuração do Supabase

### Passo 2.1: Criar Projeto no Supabase

1. Acesse https://app.supabase.com/
2. Faça login ou crie uma conta
3. Clique em **"New project"**
4. Preencha:
   - **Name:** `atria-chatbot` (ou nome de sua preferência)
   - **Database Password:** Crie uma senha forte e GUARDE-A
   - **Region:** Escolha a região mais próxima
   - **Pricing Plan:** Free (para começar)
5. Clique em **"Create new project"**
6. Aguarde 2-3 minutos até o projeto ser criado

### Passo 2.2: Obter Credenciais do Supabase

1. No dashboard do projeto, vá em **Settings** (ícone de engrenagem)
2. Clique em **API**
3. Copie e guarde em um arquivo temporário:
   - **Project URL** (exemplo: `https://xxxxxx.supabase.co`)
   - **anon public key** (começa com `eyJhbGciOi...`)

**IMPORTANTE:** Você precisará desses valores no Passo 3.2

### Passo 2.3: Configurar Banco de Dados

1. No dashboard, clique em **SQL Editor** (ícone </>)
2. Clique em **"+ New query"**
3. Abra cada arquivo de migração na pasta `supabase/migrations/` do projeto
4. Copie o conteúdo e execute na seguinte ordem:

#### Migração 1: Schema Inicial
```sql
-- Cole aqui o conteúdo de:
-- 20251105190634_create_initial_schema.sql
```
Clique em **"Run"**

#### Migração 2: Política de Usuários
```sql
-- Cole aqui o conteúdo de:
-- 20251105205809_add_users_insert_policy.sql
```
Clique em **"Run"**

#### Migração 3: Sistema de Sessões
```sql
-- Cole aqui o conteúdo de:
-- 20251110_create_sessions.sql
```
Clique em **"Run"**

#### Migração 4: Índices de Mensagens
```sql
-- Cole aqui o conteúdo de:
-- 20251110132938_add_message_lookup_index.sql
```
Clique em **"Run"**

#### Migração 5: Política de Mensagens
```sql
-- Cole aqui o conteúdo de:
-- 20251202175814_20251202_fix_messages_update_policy.sql
```
Clique em **"Run"**

#### Migração 6: Políticas de Admin
```sql
-- Cole aqui o conteúdo de:
-- 20251202175834_20251202_fix_users_admin_policies.sql
```
Clique em **"Run"**

#### Migração 7: Campos de Perfil
```sql
-- Cole aqui o conteúdo de:
-- 20251202190425_20251202_add_user_profile_fields.sql
```
Clique em **"Run"**

#### Migração 8: Correção de Políticas Admin
```sql
-- Cole aqui o conteúdo de:
-- 20251202191137_20251202_fix_users_admin_policies.sql
```
Clique em **"Run"**

#### Migração 9: Políticas Admin Ausentes
```sql
-- Cole aqui o conteúdo de:
-- 20251203204418_20251203_add_missing_admin_policies.sql
```
Clique em **"Run"**

#### Migração 10: Segurança de Funções
```sql
-- Cole aqui o conteúdo de:
-- 20251203_fix_function_search_path.sql
```
Clique em **"Run"**

**Verificação:**
- Vá em **Table Editor**
- Você deve ver as tabelas: `users`, `chat_sessions`, `messages`, `audit_logs`

### Passo 2.4: Configurar Segurança

#### Habilitar Proteção contra Senhas Vazadas

1. No dashboard, vá em **Authentication**
2. Clique na aba **Policies** (ou **Settings**)
3. Role até encontrar **"Password"** ou **"Security and Protection"**
4. Localize **"Leaked Password Protection"**
5. **Ative** a opção (toggle para ON)
6. Clique em **"Save"**

**O que isso faz:**
- Verifica senhas contra o banco de dados HaveIBeenPwned.org
- Bloqueia senhas que já foram vazadas em ataques
- Aumenta significativamente a segurança

#### Verificar Configurações de Email

1. Em **Authentication** → **Email Templates**
2. Desabilite **"Confirm email"** (a menos que queira validação por email)
3. Salve as alterações

### Passo 2.5: Implantar Edge Functions

As Edge Functions processam webhooks e integrações. Você tem duas opções:

#### Opção A: Através do Supabase Dashboard (Recomendado)

1. Vá em **Edge Functions** no menu lateral
2. Clique em **"Create a new function"**

**Função 1: send-webhook**
- Name: `send-webhook`
- Cole o conteúdo de `supabase/functions/send-webhook/index.ts`
- Clique em **"Deploy"**

**Função 2: receive-message**
- Name: `receive-message`
- Cole o conteúdo de `supabase/functions/receive-message/index.ts`
- JWT Verification: **Desativado** (público para n8n)
- Clique em **"Deploy"**

**Função 3: reset-admin-password**
- Name: `reset-admin-password`
- Cole o conteúdo de `supabase/functions/reset-admin-password/index.ts`
- Clique em **"Deploy"**

#### Opção B: Via CLI do Supabase (Avançado)

```bash
# Instalar Supabase CLI
npm install -g supabase

# Login
supabase login

# Link com o projeto
supabase link --project-ref SEU_PROJECT_REF

# Deploy das funções
supabase functions deploy send-webhook
supabase functions deploy receive-message
supabase functions deploy reset-admin-password
```

**Verificação:**
- Em **Edge Functions**, você deve ver 3 funções listadas
- Copie as URLs das funções (você precisará delas)

---

## Parte 3: Instalação do Projeto

### Passo 3.1: Obter o Projeto do GitHub

Você tem três opções para obter o projeto:

#### Opção A: Clone Direto (Recomendado para Instalação Simples)

**Via HTTPS (mais fácil, não requer configuração):**
```bash
# Clone o repositório
git clone https://github.com/USUARIO/REPO-NAME.git

# Entre na pasta do projeto
cd REPO-NAME
```

**Via SSH (requer chave SSH configurada):**
```bash
# Clone o repositório
git clone git@github.com:USUARIO/REPO-NAME.git

# Entre na pasta do projeto
cd REPO-NAME
```

**Vantagens:**
- Instalação rápida e direta
- Recebe atualizações do repositório original
- Ideal para uso imediato

**Desvantagens:**
- Não pode fazer push de alterações (somente leitura)
- Precisa de permissões para contribuir

#### Opção B: Fork + Clone (Recomendado para Desenvolvimento)

**1. Fazer Fork no GitHub:**
1. Acesse https://github.com/USUARIO/REPO-NAME
2. Clique no botão **"Fork"** no canto superior direito
3. Selecione sua conta pessoal ou organização
4. Aguarde o fork ser criado

**2. Clonar seu Fork:**
```bash
# Clone SEU fork (substitua SEU_USUARIO pelo seu nome no GitHub)
git clone https://github.com/SEU_USUARIO/REPO-NAME.git

# Entre na pasta
cd REPO-NAME

# Adicione o repositório original como upstream (para sincronizar)
git remote add upstream https://github.com/USUARIO/REPO-NAME.git

# Verifique os remotes configurados
git remote -v
```

**Vantagens:**
- Você tem controle total sobre seu fork
- Pode fazer alterações e commits livremente
- Pode criar Pull Requests para o repositório original
- Ideal para desenvolvimento e contribuições

**Sincronizar com o Repositório Original:**
```bash
# Buscar atualizações do repositório original
git fetch upstream

# Mesclar atualizações na sua branch main
git checkout main
git merge upstream/main

# Enviar para seu fork
git push origin main
```

#### Opção C: Download ZIP (Não Recomendado)

1. Acesse https://github.com/USUARIO/REPO-NAME
2. Clique no botão verde **"Code"**
3. Selecione **"Download ZIP"**
4. Extraia o arquivo ZIP
5. Abra o terminal na pasta extraída

**Desvantagens:**
- Não mantém histórico Git
- Dificulta atualizações
- Não pode fazer commits
- Use apenas para testes rápidos

#### Verificação da Instalação Git

Após clonar, verifique se está tudo certo:

```bash
# Verificar se está no repositório correto
git remote -v

# Verificar branch atual
git branch

# Verificar status
git status
```

**Saída esperada:**
```
origin  https://github.com/USUARIO/REPO-NAME.git (fetch)
origin  https://github.com/USUARIO/REPO-NAME.git (push)
```

### Passo 3.2: Criar Arquivo .env

Crie um arquivo `.env` na raiz do projeto:

```bash
# Windows
type nul > .env

# macOS/Linux
touch .env
```

Abra o arquivo `.env` e adicione:

```env
# Supabase Configuration
VITE_SUPABASE_URL=https://ykaeqjzsgysqqkutbvpi.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...

# n8n Webhook URLs
VITE_N8N_WEBHOOK_URL=https://n8n.netwise.com.br/webhook/atrIA
VITE_N8N_CREATE_ACCOUNT_WEBHOOK=https://n8n.netwise.com.br/createaccount
```

**Substitua:**
- `VITE_SUPABASE_URL`: Pela URL do seu projeto Supabase (Passo 2.2)
- `VITE_SUPABASE_ANON_KEY`: Pela chave anon do seu projeto (Passo 2.2)
- URLs do n8n: Pelos seus webhooks configurados

**IMPORTANTE:**
- Nunca comite este arquivo no Git
- O arquivo `.gitignore` já está configurado para ignorá-lo

### Passo 3.3: Instalar Dependências

```bash
npm install
```

**O que acontece:**
- Instala React, TypeScript, Vite
- Instala Supabase client
- Instala bibliotecas de UI (Tailwind, Lucide Icons)
- Instala ferramentas de desenvolvimento

**Tempo:** 1-3 minutos dependendo da conexão

### Passo 3.4: Verificar Instalação

```bash
# Verificar tipos TypeScript
npm run typecheck

# Verificar linting
npm run lint
```

**Se houver erros:**
- Verifique se o Node.js está na versão correta
- Tente deletar `node_modules` e `package-lock.json` e reinstalar

### Passo 3.5: Compilar o Projeto

```bash
npm run build
```

**O que acontece:**
- Vite compila o código TypeScript
- Otimiza arquivos CSS e JavaScript
- Gera pasta `dist/` com arquivos para produção

**Saída esperada:**
```
✓ built in 7.08s
dist/index.html                   0.72 kB
dist/assets/index-xxxxx.css      21.65 kB
dist/assets/index-xxxxx.js      408.21 kB
```

### Passo 3.6: Executar em Modo Desenvolvimento

```bash
npm run dev
```

**Saída esperada:**
```
VITE v5.4.8  ready in 500 ms

➜  Local:   http://localhost:5173/
➜  Network: use --host to expose
```

**Acesse:** http://localhost:5173/

---

## Parte 4: Configuração do n8n

### Passo 4.1: Configurar Webhook de Mensagens

No seu servidor n8n:

1. Crie um novo workflow
2. Adicione um nó **Webhook**
3. Configure:
   - **HTTP Method:** POST
   - **Path:** `atrIA` (ou personalizado)
   - **Response Mode:** Using Webhook Respond Node
4. Copie a URL do webhook

**Estrutura do Payload Recebido:**
```json
{
  "message": "Pergunta do usuário",
  "user_id": "uuid-do-usuario",
  "message_id": "uuid-da-mensagem",
  "session_id": "uuid-da-sessao",
  "callback_url": "https://xxx.supabase.co/functions/v1/receive-message"
}
```

5. Adicione lógica de processamento (IA, banco de conhecimento, etc)
6. Adicione nó **HTTP Request** para responder:
   - **Method:** POST
   - **URL:** `{{ $json.callback_url }}`
   - **Body:**
   ```json
   {
     "message_id": "{{ $json.message_id }}",
     "response": "Resposta gerada pela IA"
   }
   ```

### Passo 4.2: Configurar Webhook de Criação de Conta

1. Crie outro workflow
2. Adicione nó **Webhook**
3. Configure:
   - **HTTP Method:** POST
   - **Path:** `createaccount`
4. Copie a URL

**Payload Recebido:**
```json
{
  "email": "usuario@exemplo.com",
  "first_name": "Nome",
  "department": "n2",
  "phone": "+5511999999999",
  "created_at": "2024-12-03T00:00:00Z"
}
```

5. Adicione ações desejadas (enviar email de boas-vindas, notificar equipe, etc)

### Passo 4.3: Atualizar URLs no .env

Atualize o arquivo `.env` com as URLs dos webhooks:

```env
VITE_N8N_WEBHOOK_URL=https://seu-n8n.com/webhook/atrIA
VITE_N8N_CREATE_ACCOUNT_WEBHOOK=https://seu-n8n.com/webhook/createaccount
```

**Reinicie o servidor de desenvolvimento:**
```bash
# Pressione Ctrl+C para parar
npm run dev
```

---

## Parte 5: Primeiro Acesso e Testes

### Passo 5.1: Criar Primeira Conta

1. Acesse http://localhost:5173/
2. Você será redirecionado para `/login`
3. Clique em **"Cadastre-se"**
4. Preencha o formulário:
   - **Email:** seu@email.com
   - **Nome:** Seu Nome
   - **Telefone:** (opcional)
   - **Departamento:** Selecione um
   - **Senha:** Mínimo 6 caracteres
5. Clique em **"Cadastrar"**

**O que acontece:**
- Conta criada no Supabase Auth
- Perfil salvo na tabela `users`
- Webhook enviado para n8n (createaccount)
- Redirecionamento automático para o chat

### Passo 5.2: Tornar Usuário Admin

1. Acesse https://app.supabase.com/
2. Selecione seu projeto
3. Vá em **Table Editor** → **users**
4. Encontre seu usuário
5. Clique na célula **role**
6. Altere de `user` para `admin`
7. Pressione Enter para salvar

**Agora você tem acesso:**
- `/admin` - Painel de administração
- `/admin/settings` - Configurações do sistema
- Visualizar histórico de todos os usuários

### Passo 5.3: Testar Chat

1. Na interface do chat, digite uma mensagem
2. Clique em **"Enviar"** ou pressione Enter
3. Aguarde a resposta

**O que acontece:**
1. Frontend salva mensagem no banco
2. Edge Function `send-webhook` envia para n8n
3. n8n processa com IA
4. n8n chama `receive-message` com resposta
5. Banco atualizado com resposta
6. Frontend exibe resposta

**Se a resposta não aparecer:**
- Verifique se o n8n está ativo
- Verifique logs em Supabase → Edge Functions
- Teste o webhook manualmente (próxima seção)

### Passo 5.4: Testar Webhooks Manualmente

**Teste 1: Envio de Mensagem**

```bash
curl -X POST \
  https://SEU_PROJETO.supabase.co/functions/v1/send-webhook \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer SUA_ANON_KEY" \
  -d '{
    "message": "Teste manual",
    "user_id": "uuid-usuario",
    "message_id": "uuid-mensagem",
    "session_id": "uuid-sessao"
  }'
```

**Teste 2: Recebimento de Resposta**

```bash
curl -X POST \
  https://SEU_PROJETO.supabase.co/functions/v1/receive-message \
  -H "Content-Type: application/json" \
  -d '{
    "message_id": "uuid-mensagem",
    "response": "Resposta de teste"
  }'
```

### Passo 5.5: Verificar Logs

**Logs do Frontend:**
- Abra DevTools do navegador (F12)
- Vá na aba Console
- Verifique erros

**Logs do Supabase:**
1. Supabase Dashboard → Edge Functions
2. Clique em uma função
3. Vá na aba **Logs**
4. Verifique erros e requests

**Logs do n8n:**
1. Acesse seu n8n
2. Vá em **Executions**
3. Verifique workflows executados
4. Clique para ver detalhes

---

## Solução de Problemas

### Problema 1: "Failed to fetch" ao fazer login

**Causas:**
- URL ou chave do Supabase incorretas
- Projeto Supabase inativo

**Solução:**
1. Verifique o arquivo `.env`
2. Confirme que a URL e chave estão corretas
3. Acesse o Supabase Dashboard e veja se o projeto está ativo
4. Verifique o console do navegador (F12) para erros detalhados

### Problema 2: Erro "User already exists"

**Causa:**
- Tentando criar conta com email já cadastrado

**Solução:**
1. Use outro email
2. Ou faça login com a conta existente
3. Para resetar: Supabase Dashboard → Authentication → Users → Delete

### Problema 3: Mensagens não aparecem

**Causas:**
- n8n não está recebendo webhook
- Edge Function com erro
- Callback não está funcionando

**Solução:**
1. Verifique se n8n está ativo e acessível
2. Teste webhook manualmente (Passo 5.4)
3. Verifique logs no Supabase → Edge Functions
4. Confirme que URL de callback está correta
5. Verifique se a função `receive-message` está pública (sem JWT)

### Problema 4: Build falha

**Erro:**
```
Error: Cannot find module...
```

**Solução:**
```bash
# Limpar e reinstalar
rm -rf node_modules package-lock.json dist
npm install
npm run build
```

### Problema 5: Admin não tem acesso

**Causa:**
- Role não foi alterada para admin no banco

**Solução:**
1. Supabase → Table Editor → users
2. Encontre o usuário
3. Altere `role` para `admin`
4. Faça logout e login novamente

### Problema 6: Erros de CORS

**Sintoma:**
```
Access to fetch blocked by CORS policy
```

**Solução:**
1. Verifique que Edge Functions têm headers CORS corretos
2. Confirme que `receive-message` é pública (sem JWT)
3. Teste com Postman/Insomnia primeiro

---

## Manutenção e Atualização

### Backup do Banco de Dados

**Opção 1: Via Dashboard**
1. Supabase → Database → Backups
2. Clique em **"Create backup"**

**Opção 2: Via SQL**
```bash
# Exportar schema
pg_dump -h db.xxx.supabase.co \
  -U postgres \
  -d postgres \
  --schema-only > schema.sql

# Exportar dados
pg_dump -h db.xxx.supabase.co \
  -U postgres \
  -d postgres \
  --data-only > data.sql
```

### Atualizar Dependências

```bash
# Verificar atualizações
npm outdated

# Atualizar todas
npm update

# Atualizar versão específica
npm install react@latest

# Verificar vulnerabilidades
npm audit

# Corrigir vulnerabilidades
npm audit fix
```

### Monitoramento

**Métricas para Monitorar:**
1. **Supabase Dashboard:**
   - Database → Usage (espaço usado)
   - Edge Functions → Invocations (chamadas)
   - Authentication → Users (usuários ativos)

2. **Logs:**
   - Edge Functions → Logs (erros)
   - Database → Logs (queries lentas)

3. **Performance:**
   - Frontend: Lighthouse no Chrome DevTools
   - Backend: Query performance no Supabase

### Adicionar Novo Administrador

1. Supabase → Table Editor → users
2. Encontre o usuário
3. Altere `role` para `admin`
4. Usuário precisa fazer logout/login

### Resetar Senha de Usuário

**Como Admin:**
1. Faça login como admin
2. Vá em `/admin/settings`
3. Busque o usuário
4. Clique em **"Reset Password"**
5. Insira nova senha

**Como Usuário (futuro):**
- Implementar fluxo de "Esqueci minha senha"
- Usar Supabase Auth recovery

---

## Trabalhando com GitHub

### Workflow Básico de Desenvolvimento

**1. Criar uma Nova Branch para Suas Alterações:**
```bash
# Sempre trabalhe em uma branch separada
git checkout -b feature/minha-nova-funcionalidade

# Ou para correções de bugs
git checkout -b fix/corrigir-erro-login
```

**2. Fazer Alterações e Commits:**
```bash
# Verificar arquivos modificados
git status

# Adicionar arquivos específicos
git add src/components/NovoComponente.tsx

# Ou adicionar todos os arquivos modificados
git add .

# Fazer commit com mensagem descritiva
git commit -m "Adiciona novo componente de upload de arquivos"
```

**Boas Práticas para Commits:**
- Use mensagens claras e descritivas em português
- Prefixos úteis:
  - `Adiciona:` para novos recursos
  - `Corrige:` para correções de bugs
  - `Atualiza:` para melhorias
  - `Remove:` para remoções
  - `Refatora:` para refatorações

**3. Enviar para o GitHub:**
```bash
# Push da sua branch
git push origin feature/minha-nova-funcionalidade
```

**4. Criar Pull Request:**
1. Acesse seu repositório no GitHub
2. Clique em **"Compare & pull request"** (aparece após o push)
3. Preencha título e descrição detalhada
4. Clique em **"Create pull request"**

### Mantendo Seu Fork Atualizado

```bash
# Buscar atualizações do original
git fetch upstream

# Voltar para a branch main
git checkout main

# Mesclar atualizações
git merge upstream/main

# Enviar para seu fork
git push origin main

# Atualizar sua branch de trabalho (se necessário)
git checkout feature/minha-funcionalidade
git rebase main
```

### Resolver Conflitos

Se houver conflitos ao mesclar:

```bash
# Git mostrará os arquivos com conflito
git status

# Abra os arquivos e resolva os conflitos manualmente
# Procure por marcadores <<<<<<<, =======, >>>>>>>

# Após resolver, adicione os arquivos
git add arquivo-resolvido.tsx

# Continue o merge/rebase
git merge --continue
# ou
git rebase --continue
```

### Comandos Úteis do Git

```bash
# Ver histórico de commits
git log --oneline

# Ver diferenças antes de commitar
git diff

# Desfazer alterações em um arquivo
git checkout -- arquivo.tsx

# Voltar último commit (mantém alterações)
git reset --soft HEAD~1

# Ver branches locais
git branch

# Ver branches remotas
git branch -r

# Deletar branch local
git branch -d nome-da-branch

# Deletar branch remota
git push origin --delete nome-da-branch
```

### Deploy Automático com GitHub

#### Opção 1: Deploy no Vercel

1. Acesse https://vercel.com/
2. Faça login com sua conta GitHub
3. Clique em **"Import Project"**
4. Selecione seu repositório
5. Configure variáveis de ambiente:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
   - `VITE_N8N_WEBHOOK_URL`
   - `VITE_N8N_CREATE_ACCOUNT_WEBHOOK`
6. Clique em **"Deploy"**

**Deploy Automático:**
- Cada push na branch `main` cria um deploy em produção
- Cada Pull Request cria um preview deploy

#### Opção 2: Deploy no Netlify

1. Acesse https://netlify.com/
2. Conecte com GitHub
3. Selecione o repositório
4. Configure:
   - **Build command:** `npm run build`
   - **Publish directory:** `dist`
5. Adicione variáveis de ambiente (mesmo do Vercel)
6. Deploy

#### Opção 3: GitHub Pages (Gratuito)

**1. Configurar vite.config.ts:**
```typescript
export default defineConfig({
  base: '/REPO-NAME/',
  // ... resto da configuração
})
```

**2. Instalar gh-pages:**
```bash
npm install --save-dev gh-pages
```

**3. Adicionar scripts no package.json:**
```json
{
  "scripts": {
    "predeploy": "npm run build",
    "deploy": "gh-pages -d dist"
  }
}
```

**4. Deploy:**
```bash
npm run deploy
```

**5. Configurar no GitHub:**
- Settings → Pages
- Source: Deploy from branch `gh-pages`
- Salvar

**Acesso:** https://SEU_USUARIO.github.io/REPO-NAME/

### GitHub Actions (CI/CD Automático)

Crie `.github/workflows/deploy.yml`:

```yaml
name: Deploy

on:
  push:
    branches: [ main ]

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest

    steps:
    - uses: actions/checkout@v3

    - name: Setup Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '18'

    - name: Install dependencies
      run: npm ci

    - name: Run tests
      run: npm run typecheck

    - name: Build
      run: npm run build
      env:
        VITE_SUPABASE_URL: ${{ secrets.VITE_SUPABASE_URL }}
        VITE_SUPABASE_ANON_KEY: ${{ secrets.VITE_SUPABASE_ANON_KEY }}

    - name: Deploy to Vercel
      uses: amondnet/vercel-action@v20
      with:
        vercel-token: ${{ secrets.VERCEL_TOKEN }}
        vercel-org-id: ${{ secrets.VERCEL_ORG_ID }}
        vercel-project-id: ${{ secrets.VERCEL_PROJECT_ID }}
```

**Adicionar Secrets:**
1. GitHub → Settings → Secrets → Actions
2. Adicione cada variável de ambiente como secret

### Proteção da Branch Principal

**Recomendado para equipes:**

1. GitHub → Settings → Branches
2. Add rule para `main`
3. Habilite:
   - ✅ Require pull request before merging
   - ✅ Require approvals (1+)
   - ✅ Require status checks to pass
   - ✅ Require conversation resolution
4. Salvar

**Benefícios:**
- Previne commits diretos na main
- Exige code review
- Garante que builds passam antes de merge

---

## Próximos Passos

Após a instalação bem-sucedida:

1. **Personalize o Visual:**
   - Edite `tailwind.config.js` para cores da marca
   - Ajuste `src/index.css` para estilos globais

2. **Configure n8n Avançado:**
   - Adicione integração com LLMs (OpenAI, Claude, etc)
   - Implemente banco de conhecimento
   - Configure respostas contextuais

3. **Adicione Recursos:**
   - Upload de arquivos
   - Histórico de conversas avançado
   - Exportação de dados
   - Analytics e métricas

4. **Deploy em Produção:**
   - Escolha plataforma (Vercel, Netlify, etc)
   - Configure domínio personalizado
   - Configure SSL/HTTPS
   - Configure variáveis de ambiente na plataforma

5. **Segurança Adicional:**
   - Configure rate limiting
   - Adicione 2FA para admins
   - Implemente auditoria avançada
   - Configure backups automáticos

---

## Recursos Adicionais

**Documentação:**
- `DOCUMENTACAO_TECNICA.md` - Arquitetura e detalhes técnicos
- `USER_GUIDE.md` - Guia para usuários finais
- `TESTING.md` - Como testar o sistema
- `SUPABASE_AUTH_EXPLICACAO.md` - Detalhes de autenticação

**Links Úteis:**
- Supabase Docs: https://supabase.com/docs
- n8n Docs: https://docs.n8n.io
- React Docs: https://react.dev
- Vite Docs: https://vitejs.dev

**Suporte:**
- Consulte a documentação primeiro
- Verifique logs para diagnóstico
- Entre em contato com a equipe técnica

---

**Instalação concluída!** Você agora tem um chatbot corporativo funcional com autenticação, banco de dados e integração com IA.

**Desenvolvido com dedicação para Netwise**
