# Testing Guide

This guide will help you test all features of the AI Chat application.

## Prerequisites

Before testing, ensure you have:
- A Supabase account and project set up
- The `.env` file configured with your Supabase credentials
- AI API and n8n webhook URLs configured (optional for basic testing)

## Test Environment Setup

1. **Install Dependencies**
   ```bash
   npm install
   ```

2. **Verify Environment Variables**
   Check your `.env` file contains:
   ```
   VITE_SUPABASE_URL=your_supabase_url
   VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
   VITE_AI_API_URL=your_ai_api_url
   VITE_N8N_WEBHOOK_URL=your_n8n_webhook_url
   ```

3. **Start Development Server**
   ```bash
   npm run dev
   ```

## Test Cases

### 1. Authentication Tests

#### Test 1.1: User Registration
**Steps:**
1. Navigate to the login page
2. Click "Don't have an account? Sign up"
3. Enter a valid email and password
4. Click "Sign Up"

**Expected Result:**
- Success toast appears: "Account created successfully!"
- User is redirected to the chat page
- No email confirmation required

#### Test 1.2: User Login
**Steps:**
1. Navigate to the login page
2. Enter registered email and password
3. Click "Sign In"

**Expected Result:**
- Success toast appears: "Login successful!"
- User is redirected to the chat page

#### Test 1.3: Invalid Login
**Steps:**
1. Navigate to the login page
2. Enter incorrect credentials
3. Click "Sign In"

**Expected Result:**
- Error toast appears with authentication error message
- User remains on login page

### 2. Dark Mode Tests

#### Test 2.1: Toggle Dark Mode (Login Page)
**Steps:**
1. On the login page, locate the moon/sun icon button
2. Click the icon to toggle dark mode

**Expected Result:**
- Page switches between light and dark themes
- Icon changes from moon to sun (or vice versa)
- Theme preference is saved in localStorage
- Color scheme uses #252440 as primary dark color

#### Test 2.2: Dark Mode Persistence
**Steps:**
1. Enable dark mode
2. Refresh the page

**Expected Result:**
- Dark mode remains active after refresh
- Theme preference persists across sessions

#### Test 2.3: Dark Mode on All Pages
**Steps:**
1. Enable dark mode on login page
2. Login and navigate to chat page
3. If admin, navigate to admin dashboard and settings

**Expected Result:**
- Dark mode is consistent across all pages
- All text remains readable with proper contrast
- All interactive elements are visible

### 3. Chat Functionality Tests

#### Test 3.1: Send Message
**Steps:**
1. Login as a user
2. Type a message in the input field
3. Click the send button or press Enter

**Expected Result:**
- Message appears in the chat history
- AI response is received and displayed
- Success toast appears: "Message sent!"
- n8n webhook is triggered (if configured)
- Audit log is created

#### Test 3.2: Empty Message
**Steps:**
1. Leave the input field empty or with only spaces
2. Try to send the message

**Expected Result:**
- Send button is disabled
- No message is sent

#### Test 3.3: Message History
**Steps:**
1. Send multiple messages
2. Refresh the page

**Expected Result:**
- All previous messages are loaded and displayed
- Messages are in correct chronological order

#### Test 3.4: Long Message Handling
**Steps:**
1. Type a very long message
2. Send the message

**Expected Result:**
- Message is properly wrapped in the chat bubble
- Message is saved to database
- Page remains responsive

### 4. Admin Access Tests

#### Test 4.1: Admin Access for Regular User
**Steps:**
1. Login as a regular user (role: 'user')
2. Try to access `/admin` directly

**Expected Result:**
- User is redirected to chat page
- Admin button is not visible in header

#### Test 4.2: Admin Access for Admin User
**Steps:**
1. Login as an admin user (role: 'admin')
2. Click the "Admin" button in the chat header

**Expected Result:**
- User is redirected to admin dashboard
- Dashboard displays users list and audit logs

#### Test 4.3: View Users List
**Steps:**
1. Login as admin
2. Navigate to admin dashboard

**Expected Result:**
- All registered users are displayed
- Each user shows: email, role badge, and creation date
- Role badges are color-coded (admin: blue, user: gray)

#### Test 4.4: View Audit Logs
**Steps:**
1. Login as admin
2. Navigate to admin dashboard
3. Scroll to the "Recent Audit Logs" section

**Expected Result:**
- Last 100 audit logs are displayed
- Each log shows: truncated user ID, action, and timestamp
- Logs are sorted by most recent first

### 5. Role Management Tests

#### Test 5.1: Navigate to Admin Settings
**Steps:**
1. Login as admin
2. Navigate to admin dashboard
3. Click the "Settings" button

**Expected Result:**
- User is redirected to Admin Settings page
- All users are displayed with their current roles

#### Test 5.2: Promote User to Admin
**Steps:**
1. In Admin Settings, find a user with role 'user'
2. Click the "Promote to Admin" button

**Expected Result:**
- Success toast appears: "User role updated to admin"
- User's role badge changes to "admin" (blue)
- Button changes to "Demote to User"
- Database is updated

#### Test 5.3: Demote Admin to User
**Steps:**
1. In Admin Settings, find a user with role 'admin'
2. Click the "Demote to User" button

**Expected Result:**
- Success toast appears: "User role updated to user"
- User's role badge changes to "user" (gray)
- Button changes to "Promote to Admin"
- Database is updated

#### Test 5.4: Cannot Change Own Role
**Steps:**
1. As admin, try to change your own role

**Expected Result:**
- No promote/demote buttons appear for your account
- "(You)" label is displayed next to your email
- Error toast if somehow attempted: "You cannot change your own role"

#### Test 5.5: Role Change Verification
**Steps:**
1. Promote a user to admin
2. Logout
3. Login as that user

**Expected Result:**
- User now has access to admin dashboard
- "Admin" button appears in chat header
- User can access `/admin` and `/admin/settings`

### 6. Logout Tests

#### Test 6.1: Logout from Chat
**Steps:**
1. Login as any user
2. Click the logout icon in the chat header

**Expected Result:**
- User is redirected to login page
- Session is cleared
- Cannot access protected routes without logging in again

#### Test 6.2: Protected Routes After Logout
**Steps:**
1. Logout
2. Try to access `/chat` or `/admin` directly

**Expected Result:**
- User is redirected to login page
- Cannot access protected content

### 7. Database Integration Tests

#### Test 7.1: User Creation in Database
**Steps:**
1. Register a new user
2. Check Supabase dashboard

**Expected Result:**
- New user exists in `auth.users` table
- New user exists in `public.users` table with role 'user'

#### Test 7.2: Message Persistence
**Steps:**
1. Send a message in chat
2. Check Supabase dashboard

**Expected Result:**
- Message is saved in `messages` table
- Contains: user_id, message, response, timestamp

#### Test 7.3: Audit Log Creation
**Steps:**
1. Perform various actions (send message, login, etc.)
2. Check admin dashboard audit logs

**Expected Result:**
- Actions are logged in `audit_logs` table
- Each log contains: user_id, action description, timestamp

### 8. UI/UX Tests

#### Test 8.1: Responsive Design
**Steps:**
1. Open the app on different screen sizes
2. Test on mobile, tablet, and desktop viewports

**Expected Result:**
- Layout adapts to different screen sizes
- All features remain accessible
- No horizontal scrolling on mobile

#### Test 8.2: Theme Toggle Visibility
**Steps:**
1. Check all pages for theme toggle button
2. Verify button is accessible and visible

**Expected Result:**
- Theme toggle button is present on all pages
- Icon changes based on current theme
- Button is in a consistent location

#### Test 8.3: Loading States
**Steps:**
1. Observe loading states during actions
2. Check login, message sending, and data loading

**Expected Result:**
- Loading indicators are shown during async operations
- Buttons show "Please wait..." or "Sending..." text
- Buttons are disabled during loading

### 9. Error Handling Tests

#### Test 9.1: Network Error Handling
**Steps:**
1. Disconnect from the internet
2. Try to send a message

**Expected Result:**
- Error toast appears with appropriate message
- UI remains stable
- No data corruption

#### Test 9.2: Invalid API Configuration
**Steps:**
1. Use invalid AI API URL in `.env`
2. Try to send a message

**Expected Result:**
- Error toast appears
- Message is not saved
- User is informed of the issue

### 10. Security Tests

#### Test 10.1: Row Level Security
**Steps:**
1. Login as User A
2. Try to access User B's messages

**Expected Result:**
- User A can only see their own messages
- Database queries respect RLS policies

#### Test 10.2: Admin Route Protection
**Steps:**
1. Login as regular user
2. Manually navigate to `/admin/settings`

**Expected Result:**
- Access is denied
- User is redirected to chat page

## Test Completion Checklist

- [ ] All authentication tests pass
- [ ] Dark mode works on all pages
- [ ] Chat functionality is operational
- [ ] Admin access is properly restricted
- [ ] Role management works correctly
- [ ] Logout clears session properly
- [ ] Database integration is functioning
- [ ] UI/UX is responsive and user-friendly
- [ ] Error handling is graceful
- [ ] Security measures are effective

## Known Limitations

1. AI API and n8n webhook require external configuration
2. Email confirmation is disabled by default
3. First admin user must be manually promoted via Supabase dashboard

## Troubleshooting

### Issue: Cannot login after registration
**Solution:** Check Supabase RLS policies are properly configured

### Issue: Dark mode not persisting
**Solution:** Clear browser localStorage and try again

### Issue: Admin dashboard shows no data
**Solution:** Verify Supabase connection and check browser console for errors

### Issue: Messages not sending
**Solution:** Check AI API URL configuration in `.env` file

## Reporting Issues

If you find any bugs or issues during testing, please document:
1. Steps to reproduce
2. Expected behavior
3. Actual behavior
4. Browser and OS information
5. Screenshots or error messages
