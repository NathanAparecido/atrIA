# Como Reduzir Campos NULL no Supabase Auth

## 🎯 Problema

Você está vendo muitos campos `null` no objeto retornado pelo Supabase Auth:

```json
{
  "id": "3cf9cd1f-db63-47cd-813c-6c52db8ea851",
  "email": "antoniob8531@gmail.com",
  "banned_until": null,          ← Não usado
  "confirmed_at": null,           ← Email não confirmado
  "is_anonymous": false,
  "is_sso_user": false,
  "invited_at": null,             ← Não usado
  "last_sign_in_at": null,        ← Nunca fez login
  "phone": null,                  ← Não usado
  "confirmation_sent_at": "2025-11-06 20:53:32.414858+00"
}
```

---

## 📋 Entendendo os Campos

### **Campos que Sempre Serão NULL (Normal)**

Estes campos fazem parte da estrutura padrão do Supabase e só são preenchidos em casos específicos:

| Campo | Quando é Preenchido | Como Evitar NULL |
|-------|---------------------|-------------------|
| `phone` | Quando usa autenticação por SMS | Não usar, ou adicionar campo de telefone |
| `banned_until` | Quando admin bane um usuário | Normal ser `null` (usuário ativo) |
| `invited_at` | Quando usa sistema de convites | Não usar convites, fazer signup direto |
| `is_anonymous` | Sempre `false` (não usa auth anônimo) | - |
| `is_sso_user` | Sempre `false` (não usa OAuth) | - |

### **Campos que DEVEM Ser Preenchidos**

Estes campos estão `null` por configuração ou falta de ação:

| Campo | Por Que Está NULL | Solução |
|-------|-------------------|---------|
| `confirmed_at` | Confirmação de email habilitada | Desabilitar confirmação OU confirmar email |
| `last_sign_in_at` | Usuário nunca fez login | Aguardar primeiro login |
| `email_confirmed_at` | Email não confirmado | Auto-confirmar no signup |

---

## ✅ Solução 1: Desabilitar Confirmação de Email

### **Passo 1: Configurar no Dashboard**

```
1. Acesse: https://supabase.com/dashboard/project/ykaeqjzsgysqqkutbvpi

2. Menu lateral → Authentication → Providers → Email

3. Desabilite:
   ☐ Enable email confirmations

4. Salve
```

**Resultado:** Novos usuários já entram com `email_confirmed_at` e `confirmed_at` preenchidos automaticamente.

### **Passo 2: Confirmar Usuários Pendentes**

```sql
-- Confirmar todos os usuários pendentes
UPDATE auth.users
SET
  email_confirmed_at = NOW(),
  confirmed_at = NOW()
WHERE email_confirmed_at IS NULL;
```

---

## ✅ Solução 2: Criar Função Helper (Frontend)

Criei uma função `cleanAuthUser()` no arquivo `src/lib/auth.ts` que retorna apenas os campos relevantes:

### **Função Helper**

```typescript
// src/lib/auth.ts

export function cleanAuthUser(authUser: any) {
  return {
    id: authUser.id,
    email: authUser.email,
    created_at: authUser.created_at,
    updated_at: authUser.updated_at,
    last_sign_in_at: authUser.last_sign_in_at,
    email_confirmed_at: authUser.email_confirmed_at,
    app_metadata: authUser.app_metadata || {},
    user_metadata: authUser.user_metadata || {},
  };
}
```

### **Como Usar**

```typescript
import { cleanAuthUser } from './lib/auth';

// Antes
const { data } = await supabase.auth.getUser();
console.log(data.user); // Muitos campos null

// Depois
const { data } = await supabase.auth.getUser();
const cleanUser = cleanAuthUser(data.user);
console.log(cleanUser); // Apenas campos relevantes
```

### **Resultado**

```json
// Antes (15+ campos)
{
  "id": "...",
  "email": "...",
  "phone": null,
  "banned_until": null,
  "invited_at": null,
  "is_anonymous": false,
  "is_sso_user": false,
  ...muitos outros
}

// Depois (8 campos)
{
  "id": "...",
  "email": "...",
  "created_at": "...",
  "updated_at": "...",
  "last_sign_in_at": "...",
  "email_confirmed_at": "...",
  "app_metadata": {},
  "user_metadata": {}
}
```

---

## ✅ Solução 3: Usar Apenas public.users

Se você não precisa dos detalhes do `auth.users`, use apenas sua tabela customizada:

### **Seu Tipo de Usuário**

```typescript
// src/types/index.ts

export interface User {
  id: string;
  email: string;
  role: 'admin' | 'user';
  created_at: string;
}
```

### **Função getCurrentUser**

```typescript
// src/lib/auth.ts

export async function getCurrentUser(): Promise<User | null> {
  const { data: { user: authUser } } = await supabase.auth.getUser();

  if (!authUser) return null;

  // Busca apenas dados de public.users (sem nulls!)
  const { data: userData } = await supabase
    .from('users')
    .select('*')
    .eq('id', authUser.id)
    .maybeSingle();

  return userData as User;
}
```

### **Resultado**

```json
// Apenas os campos que VOCÊ definiu
{
  "id": "6d310071-ba37-4760-96ae-c9e54fa346d4",
  "email": "antoniobernardes@netwise.com.br",
  "role": "admin",
  "created_at": "2025-11-05 20:55:59.199296+00"
}
```

**Zero campos null!** 🎉

---

## 🎨 Solução 4: Remover Campos Null no JSON (Utilitário)

Se quiser remover `null` de qualquer objeto:

```typescript
// src/lib/utils.ts

export function removeNullFields<T>(obj: T): Partial<T> {
  return Object.fromEntries(
    Object.entries(obj as any).filter(([_, value]) => value !== null)
  ) as Partial<T>;
}

// Uso
const user = {
  id: "123",
  email: "user@example.com",
  phone: null,
  banned_until: null,
};

const cleaned = removeNullFields(user);
// { id: "123", email: "user@example.com" }
```

---

## 📊 Comparação de Abordagens

| Abordagem | Prós | Contras | Recomendado? |
|-----------|------|---------|--------------|
| **1. Desabilitar confirmação de email** | ✅ Resolve `confirmed_at` null<br>✅ UX melhor | ❌ Menos seguro (não verifica email) | ⚠️ Desenvolvimento: SIM<br>🔴 Produção: NÃO |
| **2. Helper `cleanAuthUser()`** | ✅ Código limpo<br>✅ Flexível | ❌ Precisa chamar manualmente | ✅ SIM |
| **3. Usar apenas `public.users`** | ✅ Zero nulls<br>✅ Simples | ❌ Perde dados de auth | ✅ SIM (melhor!) |
| **4. Remover nulls genericamente** | ✅ Funciona em qualquer objeto | ❌ Pode esconder bugs | ⚠️ Use com cautela |

---

## 🚀 Recomendação Final

### **Para o Seu Caso (atrIA)**

**Use a Solução 3: Trabalhe apenas com `public.users`**

```typescript
// ✅ BOM: Apenas seus campos customizados
const user = await getCurrentUser();
// { id, email, role, created_at }

// ❌ RUIM: Muitos campos do Supabase
const { data } = await supabase.auth.getUser();
// { id, email, phone: null, banned_until: null, ... }
```

**Por quê?**
1. Você controla 100% dos campos
2. Zero campos null desnecessários
3. Mais fácil de manter
4. Melhor tipagem TypeScript

---

## 🔧 Configuração Atual do Seu Projeto

### **Usuários Confirmados**

```sql
-- Estes estão OK (confirmed_at preenchido)
✅ antoniobernardes@netwise.com.br
   - confirmed_at: 2025-11-05
   - last_sign_in_at: 2025-12-02

✅ antoniob8531@gmail.com (primeiro)
   - confirmed_at: 2025-11-05
   - last_sign_in_at: 2025-12-02
```

### **Usuário Pendente**

```sql
-- Este está aguardando confirmação
❌ antoniob8531@gmail.com (novo)
   - confirmed_at: NULL
   - confirmation_sent_at: 2025-11-06
   - last_sign_in_at: NULL
```

**Para corrigir:**

```sql
-- Confirmar este usuário
UPDATE auth.users
SET
  email_confirmed_at = NOW(),
  confirmed_at = NOW()
WHERE email = 'antoniob8531@gmail.com'
AND confirmed_at IS NULL;
```

---

## 📝 Checklist de Ação

Para ter objetos mais limpos:

- [ ] **Imediato:** Use `getCurrentUser()` que retorna apenas `public.users`
- [ ] **Opcional:** Configure Dashboard para desabilitar confirmação de email (desenvolvimento)
- [ ] **Opcional:** Confirme usuários pendentes com SQL
- [ ] **Futuro:** Adicione mais campos em `public.users` conforme necessário (avatar, bio, etc)

---

## 💡 Dica Extra: TypeScript Strict

Para garantir que você nunca acesse campos null acidentalmente:

```typescript
// tsconfig.json
{
  "compilerOptions": {
    "strictNullChecks": true  // ← Força você a tratar nulls
  }
}
```

Agora o TypeScript vai avisar se você tentar usar um campo que pode ser null!

---

**Resumo:** Os campos `null` são normais na estrutura do Supabase. A melhor solução é trabalhar com `public.users` onde você controla 100% dos dados. 🎯
