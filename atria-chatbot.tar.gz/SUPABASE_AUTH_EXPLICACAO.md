# Como o Supabase Auth Funciona - Explicação Completa

## 📧 Sua Dúvida: Email de Reset de Senha

Você recebeu um email do Supabase quando tentou resetar a senha, e estava esperando configurar SMTP. Vamos entender por que isso aconteceu!

---

## 🏗️ Arquitetura do Supabase Auth

### **Schemas do Banco de Dados**

O Supabase tem **2 schemas separados**:

```
PostgreSQL Database
├── auth (schema)          ← Gerenciado pelo Supabase (você NÃO controla)
│   ├── users             ← Tabela REAL de autenticação
│   ├── sessions          ← Sessões JWT
│   ├── refresh_tokens    ← Tokens de refresh
│   ├── identities        ← OAuth providers (Google, GitHub, etc)
│   └── ...
│
└── public (schema)        ← Gerenciado por VOCÊ
    ├── users             ← SUA tabela customizada
    ├── messages
    ├── chat_sessions
    └── audit_logs
```

---

## 📊 Tabelas: auth.users vs public.users

### **auth.users (Gerenciado pelo Supabase)**

```sql
-- Esta tabela é criada e gerenciada automaticamente pelo Supabase
SELECT * FROM auth.users;

-- Colunas principais:
-- id                  - UUID único do usuário
-- email               - Email (usado para login)
-- encrypted_password  - Senha criptografada (bcrypt)
-- email_confirmed_at  - Quando email foi confirmado
-- last_sign_in_at     - Último login
-- raw_app_meta_data   - Metadata do app (JSON)
-- raw_user_meta_data  - Metadata do usuário (JSON)
-- created_at          - Data de criação
```

**Seus usuários atuais em auth.users:**
```
id: 6d310071-ba37-4760-96ae-c9e54fa346d4
email: antoniobernardes@netwise.com.br
created_at: 2025-11-05
email_confirmed_at: 2025-11-05 (confirmado automaticamente)

id: 46b56d55-ee2f-4db7-bc0e-5df7fe8863c0
email: antoniob8531@gmail.com
created_at: 2025-11-05
email_confirmed_at: 2025-11-05 (confirmado automaticamente)
```

### **public.users (Sua tabela customizada)**

```sql
-- Esta é SUA tabela que você criou
SELECT * FROM public.users;

-- Colunas:
-- id         - Mesmo UUID do auth.users (FK virtual)
-- email      - Duplicado para facilitar queries
-- role       - 'admin' ou 'user' (customizado por você)
-- created_at - Data de criação
```

**Seus usuários atuais em public.users:**
```
id: a1b2c3d4-e5f6-7890-abcd-ef1234567890
email: antoniobernardes@netwise.com.br
role: admin

id: 46b56d55-ee2f-4db7-bc0e-5df7fe8863c0
email: antoniob8531@gmail.com
role: user
```

⚠️ **PROBLEMA DETECTADO:** O ID do primeiro usuário está diferente entre as tabelas!
- `auth.users`: `6d310071-ba37-4760-96ae-c9e54fa346d4`
- `public.users`: `a1b2c3d4-e5f6-7890-abcd-ef1234567890`

Isso pode causar problemas de sincronização!

---

## 📧 Como Funciona o Sistema de Emails

### **SMTP Automático do Supabase**

O Supabase **JÁ TEM SMTP configurado** por padrão:

```
Servidor SMTP: Supabase interno
De: noreply@mail.app.supabase.io
Assunto: Reset your password for [SEU_PROJETO]
```

**Você não precisa configurar nada!** 🎉

### **Fluxo de Reset de Senha**

```
1. Usuário clica "Esqueci minha senha" → Login.tsx

2. Frontend chama:
   await supabase.auth.resetPasswordForEmail(email, {
     redirectTo: 'http://localhost:5173/login'
   })

3. Supabase Auth:
   ├─> Verifica se email existe em auth.users
   ├─> Gera token de reset (one_time_tokens)
   ├─> Envia email via SMTP interno
   └─> Email contém link: https://seu-projeto.supabase.co/auth/v1/verify?token=...&type=recovery

4. Usuário clica no link do email

5. Supabase redireciona para:
   http://localhost:5173/login#access_token=...&refresh_token=...&type=recovery

6. Frontend detecta type=recovery:
   - Mostra formulário de nova senha
   - Chama supabase.auth.updateUser({ password: novaSenha })

7. Senha atualizada em auth.users ✅
```

### **Onde o Token é Armazenado**

```sql
-- Tabela temporária de tokens
SELECT * FROM auth.one_time_tokens;

-- Colunas:
-- id
-- user_id          - FK para auth.users
-- token_hash       - Hash do token (segurança)
-- token_type       - 'recovery', 'email_change', etc
-- created_at
-- updated_at
```

---

## ⚙️ Configuração de Email (SMTP Customizado)

### **Por Que Você NÃO Precisa Configurar**

O Supabase oferece **3 opções de email**:

#### **1. SMTP Interno (Padrão) - O que você está usando**
```
✅ Funciona out-of-the-box
✅ Sem configuração
✅ Gratuito
❌ Remetente: noreply@mail.app.supabase.io (genérico)
❌ Personalização limitada
```

#### **2. SMTP Customizado (Opcional)**
```
Se quiser emails com SEU domínio (ex: noreply@atria.com.br)

Dashboard Supabase → Authentication → Email Templates → SMTP Settings

Configurar:
- SMTP Host: smtp.sendgrid.com (ou Gmail, Mailgun, etc)
- SMTP Port: 587
- SMTP User: apikey
- SMTP Password: SG.xxxxxxxxx
- From Email: noreply@atria.com.br
- From Name: atrIA
```

#### **3. SendGrid/Resend (Integração Nativa)**
```
Supabase tem integração nativa com:
- SendGrid
- Resend
- AWS SES

Melhor para produção (maior deliverability)
```

---

## 🔍 Como Visualizar os Dados de Auth

### **Via Dashboard Supabase**

```
1. Acesse: https://supabase.com/dashboard/project/ykaeqjzsgysqqkutbvpi

2. Menu lateral → Authentication → Users

Você verá TODOS os usuários de auth.users:
- Email
- Provider (email, google, github, etc)
- Created
- Last Sign In
- Email Confirmed?
```

### **Via SQL Editor**

```sql
-- Ver usuários de autenticação
SELECT
  id,
  email,
  email_confirmed_at,
  last_sign_in_at,
  created_at,
  raw_user_meta_data
FROM auth.users
ORDER BY created_at DESC;

-- Ver suas customizações
SELECT
  id,
  email,
  role,
  created_at
FROM public.users
ORDER BY created_at DESC;

-- Ver tokens de reset ativos
SELECT
  user_id,
  token_type,
  created_at
FROM auth.one_time_tokens
WHERE token_type = 'recovery'
AND created_at > NOW() - INTERVAL '1 hour';

-- Ver sessões ativas
SELECT
  user_id,
  created_at,
  updated_at
FROM auth.sessions
WHERE updated_at > NOW() - INTERVAL '1 day';
```

---

## 🔗 Sincronização: auth.users ↔ public.users

### **Como Deveria Funcionar**

```typescript
// src/lib/auth.ts - Função signUp
export async function signUp(email: string, password: string) {
  // 1. Cria usuário em auth.users
  const { data: authData, error: authError } = await supabase.auth.signUp({
    email,
    password,
  });

  if (authError) throw authError;

  // 2. Cria registro correspondente em public.users
  if (authData.user) {
    const { error: dbError } = await supabase
      .from('users')
      .insert({
        id: authData.user.id,  // ⚠️ MESMO ID!
        email: authData.user.email,
        role: 'user',
      });

    if (dbError) throw dbError;
  }

  return authData;
}
```

### **Por Que Duplicar os Dados?**

```
auth.users (Supabase)        public.users (Seu)
├── id                       ├── id (MESMO!)
├── email                    ├── email (duplicado)
├── password (criptografado) ├── role (customizado)
└── metadata                 └── created_at
```

**Motivos:**

1. **Separação de Responsabilidades**
   - `auth.users` = Autenticação (Supabase cuida)
   - `public.users` = Dados do app (você controla)

2. **RLS (Row Level Security)**
   - Policies usam `auth.uid()` que retorna `auth.users.id`
   - Você faz JOIN entre tabelas usando esse ID

3. **Customização**
   - `public.users` pode ter colunas extras (role, avatar, bio, etc)
   - `auth.users` tem colunas fixas do Supabase

---

## 🛠️ Templates de Email (Customização)

### **Como Customizar Emails**

```
Dashboard → Authentication → Email Templates

Você pode customizar:
- Confirm Signup (email de confirmação)
- Invite User (convite de admin)
- Magic Link (login sem senha)
- Change Email Address (mudança de email)
- Reset Password (recuperação de senha) ← O que você testou!
```

### **Template Padrão de Reset**

```html
<h2>Reset Your Password</h2>
<p>Follow this link to reset the password for your user:</p>
<p><a href="{{ .ConfirmationURL }}">Reset Password</a></p>

Variáveis disponíveis:
- {{ .ConfirmationURL }} - Link com token
- {{ .Token }} - Token direto
- {{ .SiteURL }} - URL do seu app
- {{ .Email }} - Email do usuário
```

### **Exemplo Customizado**

```html
<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: Arial, sans-serif; }
    .button {
      background-color: #1e3a5f;
      color: white;
      padding: 12px 24px;
      text-decoration: none;
      border-radius: 6px;
    }
  </style>
</head>
<body>
  <h1>🔐 Recuperação de Senha - atrIA</h1>
  <p>Olá,</p>
  <p>Você solicitou a recuperação de senha para <strong>{{ .Email }}</strong>.</p>
  <p>Clique no botão abaixo para criar uma nova senha:</p>
  <p>
    <a href="{{ .ConfirmationURL }}" class="button">Criar Nova Senha</a>
  </p>
  <p><small>Este link expira em 1 hora.</small></p>
  <p><small>Se você não solicitou isso, ignore este email.</small></p>
</body>
</html>
```

---

## 🔐 Segurança do Sistema de Auth

### **O Que o Supabase Faz Automaticamente**

```
✅ Passwords criptografados com bcrypt (cost factor 10)
✅ Tokens de reset expiram em 1 hora
✅ Tokens são one-time use (usado = invalidado)
✅ Rate limiting anti-brute-force
✅ Session tokens (JWT) com expiração
✅ Refresh tokens para renovação automática
✅ Email verification opcional
✅ MFA (Multi-Factor Auth) disponível
```

### **Fluxo de JWT**

```
Login bem-sucedido
    ↓
Supabase gera 2 tokens:
    ├─> access_token (JWT) - Expira em 1h
    │   └─> Contém: user_id, email, role, exp
    │
    └─> refresh_token - Expira em 30 dias
        └─> Usado para renovar access_token

Frontend armazena em localStorage:
- supabase.auth.session.access_token
- supabase.auth.session.refresh_token

Toda request ao Supabase:
- Header: Authorization: Bearer <access_token>
- RLS valida: auth.uid() == user_id do token

Token expira após 1h:
- Cliente detecta erro 401
- Usa refresh_token para pegar novo access_token
- Atualiza localStorage
- Retry da request original
```

---

## 📊 Estrutura Completa (Diagrama)

```
┌─────────────────────────────────────────────────────────┐
│                    SUPABASE CLOUD                       │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  ┌───────────────────────────────────────────────┐    │
│  │         PostgreSQL Database                    │    │
│  │                                                │    │
│  │  ┌──────────────────────────────────────┐    │    │
│  │  │  auth (schema) - Gerenciado Supabase │    │    │
│  │  │  ├── users                            │    │    │
│  │  │  ├── sessions                         │    │    │
│  │  │  ├── refresh_tokens                   │    │    │
│  │  │  ├── one_time_tokens                  │    │    │
│  │  │  ├── identities                       │    │    │
│  │  │  └── audit_log_entries               │    │    │
│  │  └──────────────────────────────────────┘    │    │
│  │                                                │    │
│  │  ┌──────────────────────────────────────┐    │    │
│  │  │  public (schema) - Você gerencia     │    │    │
│  │  │  ├── users (role, etc)               │    │    │
│  │  │  ├── messages                         │    │    │
│  │  │  ├── chat_sessions                    │    │    │
│  │  │  └── audit_logs                       │    │    │
│  │  └──────────────────────────────────────┘    │    │
│  └───────────────────────────────────────────────┘    │
│                                                         │
│  ┌───────────────────────────────────────────────┐    │
│  │         Supabase Auth (GoTrue)                │    │
│  │  ├── Login/Signup                             │    │
│  │  ├── JWT Generation                           │    │
│  │  ├── Email Sending                            │    │
│  │  └── Password Hashing                         │    │
│  └───────────────────────────────────────────────┘    │
│                                                         │
│  ┌───────────────────────────────────────────────┐    │
│  │         SMTP Interno                          │    │
│  │  noreply@mail.app.supabase.io                │    │
│  └───────────────────────────────────────────────┘    │
│                                                         │
└─────────────────────────────────────────────────────────┘
                          ↕
                 HTTPS + JWT Auth
                          ↕
┌─────────────────────────────────────────────────────────┐
│              SEU FRONTEND (React + Vite)                │
│  ├── @supabase/supabase-js                             │
│  ├── localStorage (tokens)                             │
│  └── AuthContext (gerencia sessão)                     │
└─────────────────────────────────────────────────────────┘
```

---

## 🚨 Problema Detectado no Seu Sistema

### **Inconsistência de IDs**

```sql
-- auth.users
id: 6d310071-ba37-4760-96ae-c9e54fa346d4
email: antoniobernardes@netwise.com.br

-- public.users
id: a1b2c3d4-e5f6-7890-abcd-ef1234567890  ← ❌ DIFERENTE!
email: antoniobernardes@netwise.com.br
```

**Como isso aconteceu?**

Provavelmente você criou manualmente o registro em `public.users` com ID diferente.

**Como corrigir?**

```sql
-- Opção 1: Atualizar public.users com ID correto
UPDATE public.users
SET id = '6d310071-ba37-4760-96ae-c9e54fa346d4'
WHERE email = 'antoniobernardes@netwise.com.br';

-- Opção 2: Deletar e recriar
DELETE FROM public.users WHERE email = 'antoniobernardes@netwise.com.br';
INSERT INTO public.users (id, email, role)
VALUES ('6d310071-ba37-4760-96ae-c9e54fa346d4', 'antoniobernardes@netwise.com.br', 'admin');
```

---

## 🎯 Respondendo Suas Dúvidas

### **1. Por que recebi email do Supabase?**

Porque o Supabase **já tem SMTP configurado por padrão**. Você não precisa fazer nada!

### **2. Onde configurar SMTP próprio?**

Somente se quiser emails personalizados:
- Dashboard → Authentication → Settings → SMTP Settings

### **3. Onde estão as informações de usuários?**

Em **DOIS lugares**:
- `auth.users` - Autenticação (senha, email, tokens)
- `public.users` - Dados customizados (role, perfil, etc)

### **4. Como acessar auth.users?**

Via SQL:
```sql
SELECT * FROM auth.users;
```

Via Dashboard:
```
Authentication → Users
```

### **5. Email confirmation está habilitado?**

**NÃO** no seu caso. Veja:
```
email_confirmed_at: 2025-11-05 (confirmado automaticamente)
```

Para habilitar:
```
Dashboard → Authentication → Providers → Email
☑ Enable email confirmations
```

---

## 📚 Recursos Úteis

- **Supabase Auth Docs:** https://supabase.com/docs/guides/auth
- **Email Templates:** https://supabase.com/docs/guides/auth/auth-email-templates
- **SMTP Config:** https://supabase.com/docs/guides/auth/auth-smtp
- **Your Dashboard:** https://supabase.com/dashboard/project/ykaeqjzsgysqqkutbvpi

---

**Resumo:** O Supabase já faz tudo automaticamente! Você só precisa se preocupar com SMTP customizado se quiser emails com seu domínio próprio. 🎉
