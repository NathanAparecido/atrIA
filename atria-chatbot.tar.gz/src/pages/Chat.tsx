import { useState, useEffect, useRef } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAuth } from '../components/AuthContext';
import { useToast } from '../components/ToastContext';
import { useTheme } from '../components/ThemeContext';
import { MessageRenderer } from '../components/MessageRenderer';
import { Sidebar } from '../components/Sidebar';
import { getUserSessions, getSessionMessages, savePendingMessage, createSession, deleteSession } from '../lib/db';
import { sendWebhook } from '../lib/n8n';
import { supabase } from '../lib/supabase';
import { logAudit } from '../lib/auth';
import { Message, ChatSession } from '../types';
import { Send, Bot, User as UserIcon } from 'lucide-react';

export function Chat() {
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [currentSession, setCurrentSession] = useState<ChatSession | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const { user, signOut } = useAuth();
  const { showToast } = useToast();
  const { isDark, toggleTheme } = useTheme();
  const navigate = useNavigate();
  const { sessionId } = useParams<{ sessionId: string }>();
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (user) {
      loadSessions();
    }
  }, [user]);

  useEffect(() => {
    if (user && sessionId) {
      loadSessionMessages(sessionId);
    } else if (user && sessions.length > 0 && !sessionId) {
      navigate(`/chat/${sessions[0].id}`);
    }
  }, [sessionId, user, sessions]);

  useEffect(() => {
    if (user && currentSession) {
      subscribeToMessages(currentSession.id);
    }
  }, [user, currentSession]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const loadSessions = async () => {
    if (!user) return;
    try {
      const data = await getUserSessions(user.id);
      setSessions(data);
    } catch (error) {
      showToast('Falha ao carregar conversas', 'error');
    }
  };

  const loadSessionMessages = async (sessionId: string) => {
    try {
      const data = await getSessionMessages(sessionId);
      setMessages(data);

      const session = sessions.find(s => s.id === sessionId);
      if (session) {
        setCurrentSession(session);
      } else {
        const allSessions = await getUserSessions(user!.id);
        const foundSession = allSessions.find(s => s.id === sessionId);
        if (foundSession) {
          setCurrentSession(foundSession);
          setSessions(allSessions);
        }
      }
    } catch (error) {
      showToast('Falha ao carregar mensagens', 'error');
    }
  };

  const subscribeToMessages = (sessionId: string) => {
    if (!user) return;

    const channel = supabase
      .channel(`messages-${sessionId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'messages',
          filter: `session_id=eq.${sessionId}`,
        },
        (payload) => {
          setMessages(prev => [...prev, payload.new as Message]);
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'messages',
          filter: `session_id=eq.${sessionId}`,
        },
        (payload) => {
          setMessages(prev =>
            prev.map(msg => msg.id === payload.new.id ? payload.new as Message : msg)
          );
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleNewChat = async () => {
    if (!user) return;

    try {
      const newSession = await createSession(user.id);
      setSessions(prev => [newSession, ...prev]);
      navigate(`/chat/${newSession.id}`);
      setMessages([]);
      setSidebarOpen(false);
      showToast('Nova conversa criada', 'success');
    } catch (error) {
      showToast('Falha ao criar conversa', 'error');
    }
  };

  const handleSelectSession = (sessionId: string) => {
    navigate(`/chat/${sessionId}`);
    setSidebarOpen(false);
  };

  const handleDeleteSession = async (sessionId: string) => {
    if (!user) return;

    if (!confirm('Tem certeza que deseja deletar esta conversa? Esta ação não pode ser desfeita.')) {
      return;
    }

    try {
      await deleteSession(sessionId);
      setSessions(prev => prev.filter(s => s.id !== sessionId));

      if (currentSession?.id === sessionId) {
        const remainingSessions = sessions.filter(s => s.id !== sessionId);
        if (remainingSessions.length > 0) {
          navigate(`/chat/${remainingSessions[0].id}`);
        } else {
          await handleNewChat();
        }
      }

      showToast('Conversa deletada', 'success');
    } catch (error) {
      showToast('Falha ao deletar conversa', 'error');
    }
  };

  const handleSend = async () => {
    if (!input.trim() || !user || !currentSession || loading) return;

    const userMessage = input.trim();
    setInput('');
    setLoading(true);

    try {
      const savedMessage = await savePendingMessage(user.id, currentSession.id, userMessage);
      setMessages(prev => [...prev, savedMessage]);

      sendWebhook({
        event: 'message_sent',
        user_id: user.id,
        session_id: currentSession.id,
        message_id: savedMessage.id,
        message: userMessage,
        timestamp: new Date().toISOString(),
      });

      setTimeout(() => {
        setMessages(prev => {
          const msg = prev.find(m => m.id === savedMessage.id);
          if (msg && msg.response === null) {
            showToast('A IA está demorando para responder. Tente novamente.', 'error');
            return prev.map(m =>
              m.id === savedMessage.id
                ? { ...m, response: '[Timeout] A IA não respondeu a tempo. Por favor, tente enviar novamente.' }
                : m
            );
          }
          return prev;
        });
      }, 30000);

      logAudit(user.id, `Sent message: ${userMessage.substring(0, 50)}`);
    } catch (error) {
      showToast('Falha ao enviar mensagem', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut();
      navigate('/login');
    } catch (error) {
      showToast('Falha ao sair', 'error');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex transition-colors relative">
      <Sidebar
        user={user}
        sessions={sessions}
        currentSessionId={currentSession?.id || null}
        isDark={isDark}
        isOpen={sidebarOpen}
        onNewChat={handleNewChat}
        onSelectSession={handleSelectSession}
        onDeleteSession={handleDeleteSession}
        onToggleTheme={toggleTheme}
        onLogout={handleLogout}
        onToggleSidebar={() => setSidebarOpen(!sidebarOpen)}
      />

      <main className={`flex-1 flex flex-col overflow-hidden transition-all duration-300 ${sidebarOpen ? 'ml-72' : 'ml-0'}`}>
        <div className="flex-1 overflow-y-auto p-6 space-y-6 max-w-4xl w-full mx-auto">
          {!currentSession ? (
            <div className="flex items-center justify-center h-full text-gray-500 dark:text-gray-400 transition-colors">
              <div className="text-center">
                <Bot className="w-16 h-16 mx-auto mb-4 text-gray-300 dark:text-gray-600" />
                <p className="text-lg font-medium mb-2 text-gray-900 dark:text-gray-100">Bem-vindo ao atrIA</p>
                <p className="text-sm mb-4">Crie uma nova conversa para começar</p>
                <button
                  onClick={handleNewChat}
                  className="px-6 py-3 bg-primary-600 hover:bg-primary-700 text-white rounded-lg transition-colors"
                >
                  Criar Novo Chat
                </button>
              </div>
            </div>
          ) : messages.length === 0 ? (
            <div className="flex items-center justify-center h-full text-gray-500 dark:text-gray-400 transition-colors">
              <div className="text-center">
                <Bot className="w-16 h-16 mx-auto mb-4 text-gray-300 dark:text-gray-600" />
                <p className="text-lg font-medium mb-2 text-gray-900 dark:text-gray-100">Conversa vazia</p>
                <p className="text-sm">Comece fazendo uma pergunta</p>
              </div>
            </div>
          ) : (
            messages.map((msg) => (
              <div key={msg.id} className="space-y-6">
                <div className="flex gap-4 justify-end items-start">
                  <div className="flex-1 flex justify-end">
                    <div className="bg-primary-600 dark:bg-primary-700 text-white px-5 py-3 rounded-2xl max-w-2xl shadow-sm">
                      <MessageRenderer content={msg.message} isUser />
                    </div>
                  </div>
                  <div className="w-8 h-8 rounded-full bg-primary-600 dark:bg-primary-700 flex items-center justify-center flex-shrink-0">
                    <UserIcon className="w-5 h-5 text-white" />
                  </div>
                </div>

                <div className="flex gap-4 items-start">
                  <div className="w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center flex-shrink-0">
                    <Bot className="w-5 h-5 text-gray-600 dark:text-gray-300" />
                  </div>
                  <div className="flex-1">
                    <div className="bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-gray-100 px-5 py-4 rounded-2xl max-w-2xl shadow-sm">
                      {msg.response ? (
                        <MessageRenderer content={msg.response} />
                      ) : (
                        <div className="flex items-center gap-2 text-gray-500 dark:text-gray-400">
                          <div className="flex gap-1">
                            <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></span>
                            <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></span>
                            <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></span>
                          </div>
                          <span className="text-sm">Pensando...</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
          <div ref={messagesEndRef} />
        </div>

        <div className="border-t border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 p-4 transition-colors">
          <div className="max-w-4xl mx-auto flex gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && !e.shiftKey && handleSend()}
              placeholder="Digite sua mensagem..."
              disabled={loading || !currentSession}
              className="flex-1 px-4 py-3 border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white rounded-lg focus:ring-2 focus:ring-primary-600 dark:focus:ring-primary-500 focus:border-transparent outline-none transition-colors disabled:opacity-50"
            />
            <button
              onClick={handleSend}
              disabled={loading || !input.trim() || !currentSession}
              className="px-6 py-3 bg-primary-600 hover:bg-primary-700 dark:bg-primary-600 dark:hover:bg-primary-700 text-white rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
            >
              {loading ? 'Enviando...' : <Send className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </main>
    </div>
  );
}
