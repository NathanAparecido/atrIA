import { supabase } from './supabase';
import { User, SignUpData } from '../types';

export function removeNull<T>(obj: T): Partial<T> {
  return Object.fromEntries(
    Object.entries(obj as any).filter(([_, v]) => v !== null)
  ) as Partial<T>;
}

export function cleanAuthUser(authUser: any) {
  return removeNull({
    id: authUser.id,
    email: authUser.email,
    created_at: authUser.created_at,
    updated_at: authUser.updated_at,
    last_sign_in_at: authUser.last_sign_in_at,
    email_confirmed_at: authUser.email_confirmed_at,
    app_metadata: authUser.app_metadata || {},
    user_metadata: authUser.user_metadata || {},
  });
}

export async function getSession() {
  const { data, error } = await supabase.auth.getSession();
  if (error) throw error;
  return data?.session ?? null;
}

async function sendWebhook(userData: {
  id: string;
  email: string;
  firstName: string;
  phone: string | null;
  department: string;
  role: string;
  createdAt: string;
}) {
  try {
    const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/send-webhook`;

    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
      },
      body: JSON.stringify({
        url: 'https://n8n.netwise.com.br/webhook-test/createaccount',
        data: userData,
      }),
    });

    if (!response.ok) {
      console.error('Webhook failed:', response.status, response.statusText);
    }
  } catch (error) {
    console.error('Failed to send webhook:', error);
  }
}

export async function signUp(signUpData: SignUpData) {
  const { email, password, firstName, phone, department } = signUpData;

  const { data: authData, error: authError } = await supabase.auth.signUp({
    email,
    password,
    options: {
      emailRedirectTo: `${window.location.origin}/login`,
    },
  });

  if (authError) throw authError;

  if (authData.user) {
    const userData = {
      id: authData.user.id,
      email: authData.user.email!,
      first_name: firstName,
      phone: phone || null,
      department,
      role: 'user',
    };

    const { error: dbError } = await supabase
      .from('users')
      .insert(userData);

    if (dbError) throw dbError;

    await sendWebhook({
      id: userData.id,
      email: userData.email,
      firstName: userData.first_name,
      phone: userData.phone,
      department: userData.department,
      role: userData.role,
      createdAt: authData.user.created_at,
    });
  }

  return authData;
}

export async function signIn(email: string, password: string) {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });

  if (error) throw error;

  return data;
}

export async function signOut() {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
}

export async function getCurrentUser(): Promise<User | null> {
  const { data: { user: authUser } } = await supabase.auth.getUser();

  if (!authUser) return null;

  const { data: userData, error } = await supabase
    .from('users')
    .select('*')
    .eq('id', authUser.id)
    .single();

  if (error) {
    if (error.code === 'PGRST116') {
      return null;
    }
    throw error;
  }

  return userData as User;
}

export async function resetPassword(email: string) {
  const { error } = await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: `${window.location.origin}/login`,
  });

  if (error) throw error;
}

export async function logAudit(userId: string, action: string) {
  await supabase
    .from('audit_logs')
    .insert({
      user_id: userId,
      action,
    });
}
