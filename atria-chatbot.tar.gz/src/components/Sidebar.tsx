import { ChatSession, User } from '../types';
import { Plus, MessageSquare, Trash2, LogOut, Moon, Sun, User as UserIcon, ChevronLeft, ChevronRight } from 'lucide-react';

interface SidebarProps {
  user: User | null;
  sessions: ChatSession[];
  currentSessionId: string | null;
  isDark: boolean;
  isOpen: boolean;
  onNewChat: () => void;
  onSelectSession: (sessionId: string) => void;
  onDeleteSession: (sessionId: string) => void;
  onToggleTheme: () => void;
  onLogout: () => void;
  onToggleSidebar: () => void;
}

export function Sidebar({
  user,
  sessions,
  currentSessionId,
  isDark,
  isOpen,
  onNewChat,
  onSelectSession,
  onDeleteSession,
  onToggleTheme,
  onLogout,
  onToggleSidebar,
}: SidebarProps) {
  return (
    <>
      {/* Sidebar */}
      <aside
        className={`fixed top-0 left-0 h-screen bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-700 w-72 flex flex-col z-50 transform transition-all duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Header */}
        <div className="p-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold text-primary-600 dark:text-primary-400 tracking-wider">atrIA</h1>
          </div>

          <button
            onClick={onNewChat}
            className="w-full px-4 py-3 bg-primary-600 hover:bg-primary-700 text-white rounded-lg flex items-center gap-2 justify-center transition-colors"
          >
            <Plus className="w-5 h-5" />
            <span className="font-medium">Novo Chat</span>
          </button>
        </div>

        {/* Chat Sessions List */}
        <div className="flex-1 overflow-y-auto p-3 space-y-1">
          {sessions.map((session) => (
            <div
              key={session.id}
              className={`group relative flex items-center gap-2 p-3 rounded-lg cursor-pointer transition-colors ${
                currentSessionId === session.id
                  ? 'bg-gray-100 dark:bg-gray-800'
                  : 'hover:bg-gray-50 dark:hover:bg-gray-800'
              }`}
              onClick={() => onSelectSession(session.id)}
            >
              <MessageSquare className="w-4 h-4 flex-shrink-0 text-gray-500 dark:text-gray-400" />
              <div className="flex-1 min-w-0">
                <p className="text-sm truncate text-gray-900 dark:text-gray-100">{session.title}</p>
                <p className="text-xs text-gray-500 dark:text-gray-500">
                  {new Date(session.updated_at).toLocaleDateString('pt-BR', {
                    day: '2-digit',
                    month: 'short',
                  })}
                </p>
              </div>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onDeleteSession(session.id);
                }}
                className="opacity-0 group-hover:opacity-100 p-1 hover:bg-gray-200 dark:hover:bg-gray-700 rounded transition-all"
                title="Deletar conversa"
              >
                <Trash2 className="w-4 h-4 text-red-500" />
              </button>
            </div>
          ))}
        </div>

        {/* Footer - User Controls */}
        <div className="border-t border-gray-200 dark:border-gray-700 p-3 space-y-2">
          <div className="flex items-center gap-2 px-3 py-2 text-sm bg-gray-50 dark:bg-gray-800 rounded-lg">
            <UserIcon className="w-4 h-4 text-gray-500 dark:text-gray-400" />
            <span className="flex-1 truncate text-gray-900 dark:text-gray-100">{user?.email}</span>
          </div>

          <div className="flex gap-2">
            <button
              onClick={onToggleTheme}
              className="flex-1 px-3 py-2 bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 rounded-lg flex items-center justify-center gap-2 transition-colors"
              title="Alternar tema"
            >
              {isDark ? <Sun className="w-4 h-4 text-gray-900 dark:text-gray-100" /> : <Moon className="w-4 h-4 text-gray-900 dark:text-gray-100" />}
              <span className="text-sm text-gray-900 dark:text-gray-100">{isDark ? 'Claro' : 'Escuro'}</span>
            </button>

            <button
              onClick={onLogout}
              className="px-3 py-2 bg-red-600 hover:bg-red-700 rounded-lg transition-colors"
              title="Sair"
            >
              <LogOut className="w-4 h-4 text-white" />
            </button>
          </div>
        </div>
      </aside>

      {/* Toggle Button */}
      <button
        onClick={onToggleSidebar}
        className={`fixed top-4 z-40 p-2 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg transition-all duration-300 hover:bg-gray-50 dark:hover:bg-gray-700 ${
          isOpen ? 'left-[17rem]' : 'left-4'
        }`}
      >
        {isOpen ? (
          <ChevronLeft className="w-5 h-5 text-gray-900 dark:text-gray-100" />
        ) : (
          <ChevronRight className="w-5 h-5 text-gray-900 dark:text-gray-100" />
        )}
      </button>
    </>
  );
}
