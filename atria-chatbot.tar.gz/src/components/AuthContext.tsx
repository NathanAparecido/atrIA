import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, AuthState, SignUpData } from '../types';
import { getCurrentUser, signIn as authSignIn, signOut as authSignOut, signUp as authSignUp, resetPassword as authResetPassword } from '../lib/auth';
import { supabase } from '../lib/supabase';

interface AuthContextType extends AuthState {
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (signUpData: SignUpData) => Promise<void>;
  signOut: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getCurrentUser()
      .then(setUser)
      .catch(() => setUser(null))
      .finally(() => setLoading(false));

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event) => {
      (async () => {
        if (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED') {
          const currentUser = await getCurrentUser();
          setUser(currentUser);
        } else if (event === 'SIGNED_OUT') {
          setUser(null);
        }
      })();
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const signIn = async (email: string, password: string) => {
    await authSignIn(email, password);
    const currentUser = await getCurrentUser();
    setUser(currentUser);
  };

  const signUp = async (signUpData: SignUpData) => {
    await authSignUp(signUpData);
    const currentUser = await getCurrentUser();
    setUser(currentUser);
  };

  const signOut = async () => {
    await authSignOut();
    setUser(null);
  };

  const resetPassword = async (email: string) => {
    await authResetPassword(email);
  };

  return (
    <AuthContext.Provider value={{ user, loading, signIn, signUp, signOut, resetPassword }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
}
