import { createClient } from 'npm:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false,
        },
      }
    );

    const adminEmail = 'antoniobernardes@netwise.com.br';
    const adminPassword = 'admin';
    const adminId = 'a1b2c3d4-e5f6-7890-abcd-ef1234567890';

    // Delete existing auth user if exists
    const { data: existingUser } = await supabaseAdmin.auth.admin.listUsers();
    const userToDelete = existingUser?.users.find(u => u.email === adminEmail);
    
    if (userToDelete) {
      await supabaseAdmin.auth.admin.deleteUser(userToDelete.id);
    }

    // Create new auth user with specific ID
    const { data: newUser, error: createError } = await supabaseAdmin.auth.admin.createUser({
      email: adminEmail,
      password: adminPassword,
      email_confirm: true,
      user_metadata: { role: 'admin' },
    });

    if (createError) throw createError;

    // Update the users table to link the correct ID
    const { error: updateError } = await supabaseAdmin
      .from('users')
      .update({ id: newUser.user.id })
      .eq('id', adminId);

    if (updateError) throw updateError;

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'Admin password reset successfully',
        userId: newUser.user.id
      }),
      {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message 
      }),
      {
        status: 400,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});