import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface IncomingMessage {
  user_id: string;
  session_id: string;
  message_id?: string;
  message: string;
  response: string;
}

Deno.serve(async (req: Request) => {
  const startTime = Date.now();

  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const payload: IncomingMessage = await req.json();
    console.log(`[${Date.now() - startTime}ms] Received payload`);

    if (!payload.response) {
      return new Response(
        JSON.stringify({ error: "Missing required field: response" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    let data, error;

    if (payload.message_id) {
      const result = await supabase
        .from("messages")
        .update({ response: payload.response })
        .eq("id", payload.message_id)
        .is("response", null)
        .select()
        .maybeSingle();
      data = result.data;
      error = result.error;
    } else {
      if (!payload.user_id || !payload.session_id || !payload.message) {
        return new Response(
          JSON.stringify({ error: "Missing required fields: user_id, session_id, message (or message_id)" }),
          {
            status: 400,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          }
        );
      }

      const result = await supabase
        .from("messages")
        .update({ response: payload.response })
        .eq("user_id", payload.user_id)
        .eq("session_id", payload.session_id)
        .eq("message", payload.message)
        .is("response", null)
        .order("created_at", { ascending: false })
        .limit(1)
        .select()
        .maybeSingle();
      data = result.data;
      error = result.error;
    }

    console.log(`[${Date.now() - startTime}ms] Database update complete`);

    if (error) {
      console.error("Database error:", error);
      return new Response(
        JSON.stringify({ error: "Failed to save message", details: error.message }),
        {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    console.log(`[${Date.now() - startTime}ms] Sending response`);

    return new Response(
      JSON.stringify({ success: true, message: data }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    console.error("Error:", error);
    return new Response(
      JSON.stringify({ error: "Internal server error", details: error.message }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});