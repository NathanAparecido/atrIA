/*
  # Add User Profile Fields

  1. Changes
    - Add `first_name` column (text, required)
    - Add `phone` column (text, optional)
    - Add `department` column (text, required)
      - Valid values: 'n2', 'noc', 'financeiro', 'tecnico_campo', 'infra', 'n3', 'comercial', 'gerencia', 'diretoria'

  2. Security
    - Users can update their own profile fields
    - Add new RLS policies for update operations
*/

-- Add new columns to users table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' 
    AND table_name = 'users' 
    AND column_name = 'first_name'
  ) THEN
    ALTER TABLE public.users ADD COLUMN first_name text NOT NULL DEFAULT '';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public'
    AND table_name = 'users'
    AND column_name = 'phone'
  ) THEN
    ALTER TABLE public.users ADD COLUMN phone text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public'
    AND table_name = 'users'
    AND column_name = 'department'
  ) THEN
    ALTER TABLE public.users ADD COLUMN department text NOT NULL DEFAULT 'n2';
  END IF;
END $$;

-- Create index for department queries
CREATE INDEX IF NOT EXISTS idx_users_department ON public.users(department);

-- Add check constraint for valid departments
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'users_department_check'
  ) THEN
    ALTER TABLE public.users
    ADD CONSTRAINT users_department_check
    CHECK (department IN ('n2', 'noc', 'financeiro', 'tecnico_campo', 'infra', 'n3', 'comercial', 'gerencia', 'diretoria'));
  END IF;
END $$;

-- Add policy for users to update their own profile
DROP POLICY IF EXISTS "Users can update own profile" ON public.users;
CREATE POLICY "Users can update own profile"
  ON public.users
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);