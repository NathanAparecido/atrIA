/*
  # Add index for faster message lookup

  1. Performance
    - Create composite index on (user_id, message, response) for faster pending message lookups
    - This will dramatically speed up the edge function query that searches for pending messages

  2. Notes
    - Index includes WHERE clause for null responses to make it more efficient
    - This is a partial index that only indexes messages with null responses
*/

CREATE INDEX IF NOT EXISTS idx_messages_pending_lookup 
ON messages (user_id, message, created_at DESC) 
WHERE response IS NULL;