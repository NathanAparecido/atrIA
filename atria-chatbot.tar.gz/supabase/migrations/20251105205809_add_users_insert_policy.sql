/*
  # Add Insert Policy for Users Table

  1. Changes
    - Add INSERT policy for users table to allow new user registration
    - Users can create their own record during signup
  
  2. Security
    - Policy ensures users can only insert their own record (auth.uid() matches)
*/

CREATE POLICY "Users can insert own data"
  ON users FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);
