/*
  # Add Missing Admin Policies

  1. Problem
    - Admin users cannot view all users in the admin panel
    - Admin users cannot view all messages for moderation
    - RLS is blocking admin access even though they have role='admin'

  2. Solution
    - Add policies that check if user has role='admin' in users table
    - Allow admins to SELECT all records from users and messages tables
    - These policies only grant READ access, not write access

  3. Security
    - Policies verify admin role from users table
    - Only authenticated users can use these policies
    - Write operations still restricted to own data
*/

-- Policy: Admins can view all users
CREATE POLICY "Admins can view all users"
  ON public.users FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.users AS u
      WHERE u.id = auth.uid()
      AND u.role = 'admin'
    )
  );

-- Policy: Admins can view all messages
CREATE POLICY "Admins can view all messages"
  ON public.messages FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.users
      WHERE users.id = auth.uid()
      AND users.role = 'admin'
    )
  );

-- Policy: Admins can view all chat sessions
CREATE POLICY "Admins can view all sessions"
  ON public.chat_sessions FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.users
      WHERE users.id = auth.uid()
      AND users.role = 'admin'
    )
  );
