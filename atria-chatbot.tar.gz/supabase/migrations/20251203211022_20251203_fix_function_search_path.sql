/*
  # Correção de Segurança: Search Path das Funções

  1. Problema
    - As funções `update_chat_session_timestamp` e `update_session_on_message` 
      têm search_path mutável, o que é um risco de segurança
    - Atacantes podem manipular o search_path para executar código malicioso

  2. Solução
    - Recriar as funções com `SET search_path = public, pg_temp`
    - Isso garante que apenas os schemas public e pg_temp sejam utilizados
    - Previne ataques de injeção via search_path

  3. Funções Corrigidas
    - `update_chat_session_timestamp()` - Atualiza timestamp de sessão
    - `update_session_on_message()` - Atualiza timestamp quando mensagem é criada

  Referência: https://www.postgresql.org/docs/current/sql-createfunction.html
*/

-- Recriar função update_chat_session_timestamp com search_path seguro
CREATE OR REPLACE FUNCTION update_chat_session_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql
SET search_path = public, pg_temp;

-- Recriar função update_session_on_message com search_path seguro
CREATE OR REPLACE FUNCTION update_session_on_message()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE chat_sessions
  SET updated_at = now()
  WHERE id = NEW.session_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql
SET search_path = public, pg_temp;