/*
  # Fix Admin RLS Policies - Remove Infinite Recursion

  1. Problem
    - Admin policies were doing SELECT on users table within the policy condition
    - This creates infinite recursion: to read users, need to check if admin, to check if admin, need to read users...
    - Error: "infinite recursion detected in policy for relation users"

  2. Solution
    - Remove the recursive SELECT policies for admins
    - Admin privileges should be managed differently (via app_metadata or separate function)
    - Keep simple policies: users can only see/edit their own data
    - Admins will use service role key for admin operations

  3. Changes
    - DROP admin policies that cause recursion
    - Keep only user-level policies (auth.uid() = id)
*/

-- Drop problematic admin policies
DROP POLICY IF EXISTS "Admins can view all users" ON public.users;
DROP POLICY IF EXISTS "Admins can update users" ON public.users;

-- Keep simple, non-recursive policies
-- Users can view own data
-- Users can insert own data  
-- Users can update own profile

-- These policies already exist and work correctly:
-- 1. "Users can view own data" - SELECT WHERE auth.uid() = id
-- 2. "Users can insert own data" - INSERT WITH CHECK auth.uid() = id
-- 3. "Users can update own profile" - UPDATE WHERE/WITH CHECK auth.uid() = id
