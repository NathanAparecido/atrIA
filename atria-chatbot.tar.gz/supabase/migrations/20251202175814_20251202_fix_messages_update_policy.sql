/*
  # Fix Messages UPDATE Policy

  1. Changes
    - Add UPDATE policy for messages table to allow Edge Function to update responses
    - Service role can update any message (bypasses RLS when using SERVICE_ROLE_KEY)
    - Authenticated users can update their own pending messages

  2. Security
    - Service role policy allows Edge Function to work
    - User policy prevents users from modifying messages after response is set
*/

-- Policy for service_role (used by Edge Function)
CREATE POLICY "Service role can update messages"
  ON messages FOR UPDATE
  TO service_role
  USING (true)
  WITH CHECK (true);

-- Policy for authenticated users (can update only pending messages)
CREATE POLICY "Users can update own pending messages"
  ON messages FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id AND response IS NULL)
  WITH CHECK (auth.uid() = user_id);