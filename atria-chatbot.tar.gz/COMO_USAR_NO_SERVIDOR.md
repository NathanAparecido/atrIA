# 📦 Como usar o atria-chatbot.tar.gz no seu servidor

## 🚀 Instalação Rápida

### 1. Fazer upload do arquivo para o servidor

No seu computador local, copie o arquivo para o servidor:

```bash
scp atria-chatbot.tar.gz root@SEU_IP:/opt/
```

### 2. Extrair no servidor

No servidor:

```bash
# Criar diretório
mkdir -p /opt/atria

# Extrair arquivo (IMPORTANTE: use -C para extrair no diretório correto)
tar -xzf /opt/atria-chatbot.tar.gz -C /opt/atria

# Verificar se extraiu tudo
ls -la /opt/atria/

# Deve mostrar: Dockerfile, docker-compose.yml, src/, package.json, etc.

# Remover o arquivo compactado (opcional)
rm /opt/atria-chatbot.tar.gz
```

### 3. Configurar variáveis de ambiente

```bash
cd /opt/atria

# Copiar exemplo
cp .env.example .env

# Editar com suas credenciais
nano .env
```

Preencha com suas credenciais do Supabase:

```env
VITE_SUPABASE_URL=https://seu-projeto.supabase.co
VITE_SUPABASE_ANON_KEY=sua-chave-anon-aqui
VITE_N8N_WEBHOOK_URL=https://sua-instancia-n8n.com/webhook/seu-endpoint
```

### 4. Iniciar com Docker

```bash
cd /opt/atria

# Build e iniciar
docker compose up -d --build

# Ver logs
docker compose logs -f
```

### 5. Acessar a aplicação

Abra no navegador:

```
http://SEU_IP:8080
```

## 🔐 Primeiro acesso

**Usuário padrão:**
- Email: `admin@atria.com`
- Senha: `admin123`

**IMPORTANTE:** Mude a senha imediatamente após o primeiro login!

## 🔧 Comandos úteis

```bash
# Ver status
docker compose ps

# Parar
docker compose down

# Reiniciar
docker compose restart

# Ver logs
docker compose logs -f atria-chatbot

# Atualizar após mudanças
docker compose up -d --build
```

## 📋 Checklist pós-instalação

- [ ] .env configurado com credenciais do Supabase
- [ ] Container rodando (`docker compose ps`)
- [ ] Aplicação acessível no navegador
- [ ] Login funcionando
- [ ] Senha do admin alterada
- [ ] Webhook do n8n configurado (se necessário)

## 🐛 Problemas comuns

### Container não inicia
```bash
docker compose logs atria-chatbot
```

### Porta 8080 já em uso
Edite `docker-compose.yml` e mude para outra porta:
```yaml
ports:
  - "8081:80"  # Mude para 8081 ou outra porta livre
```

### Erro de conexão com Supabase
Verifique se as credenciais no `.env` estão corretas.

## 📞 Suporte

Para mais informações, consulte:
- `DOCKER_SETUP.md` - Documentação completa do Docker
- `README.md` - Visão geral do projeto
- `USER_GUIDE.md` - Guia do usuário
