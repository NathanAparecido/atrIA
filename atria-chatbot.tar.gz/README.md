# AtrIA Chatbot 🤖

<div align="center">

**Chatbot Corporativo Inteligente com IA**

[![React](https://img.shields.io/badge/React-18.3-61DAFB?logo=react&logoColor=white)](https://react.dev/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.5-3178C6?logo=typescript&logoColor=white)](https://www.typescriptlang.org/)
[![Supabase](https://img.shields.io/badge/Supabase-2.57-3ECF8E?logo=supabase&logoColor=white)](https://supabase.com/)
[![Vite](https://img.shields.io/badge/Vite-5.4-646CFF?logo=vite&logoColor=white)](https://vitejs.dev/)
[![License](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

[Demo](#) • [Documentação](GUIA_INSTALACAO_COMPLETO.md) • [Contribuir](#contribuindo)

</div>

---

## 📋 Sobre o Projeto

AtrIA é um chatbot corporativo moderno desenvolvido para atender às necessidades de comunicação interna das empresas. Integrado com inteligência artificial através do n8n, oferece respostas contextuais e inteligentes, mantendo um histórico completo de conversas.

### 🎯 Principais Recursos

- ✅ **Autenticação Segura** - Sistema completo de login/registro com Supabase Auth
- ✅ **Chat em Tempo Real** - Interface responsiva e intuitiva
- ✅ **Integração com IA** - Processamento inteligente via n8n + LLMs
- ✅ **Histórico Completo** - Todas as conversas são armazenadas e consultáveis
- ✅ **Painel Admin** - Gestão de usuários e configurações
- ✅ **Markdown Support** - Respostas formatadas com sintaxe rica
- ✅ **Modo Escuro/Claro** - Interface adaptável às preferências do usuário
- ✅ **Multi-departamento** - Suporte para diferentes áreas da empresa
- ✅ **Auditoria Completa** - Logs de todas as ações importantes
- ✅ **RLS (Row Level Security)** - Segurança em nível de linha no banco de dados

---

## 🚀 Tecnologias

Este projeto foi construído com as seguintes tecnologias:

### Frontend
- **React 18** - Biblioteca UI moderna e eficiente
- **TypeScript** - Tipagem estática para código mais seguro
- **Vite** - Build tool rápido e moderno
- **Tailwind CSS** - Framework CSS utility-first
- **React Router** - Roteamento do lado do cliente
- **Lucide Icons** - Conjunto de ícones SVG

### Backend
- **Supabase** - Backend as a Service (BaaS)
  - PostgreSQL Database
  - Authentication & Authorization
  - Row Level Security (RLS)
  - Edge Functions
  - Real-time subscriptions (futuro)

### Integração
- **n8n** - Plataforma de automação e workflow
- **LLMs** - Modelos de linguagem (OpenAI, Claude, etc)

---

## 📸 Screenshots

### Interface de Chat
```
[Captura de tela da interface do chat]
- Mensagens em tempo real
- Suporte a Markdown
- Indicador de digitação
```

### Painel Administrativo
```
[Captura de tela do painel admin]
- Lista de usuários
- Estatísticas de uso
- Configurações do sistema
```

---

## 🏁 Quick Start

### Pré-requisitos

- Node.js 18+ instalado
- Git instalado
- Conta Supabase (gratuita)
- Servidor n8n configurado

### Instalação Rápida

```bash
# 1. Clone o repositório
git clone https://github.com/SEU_USUARIO/atria-chatbot.git
cd atria-chatbot

# 2. Instale as dependências
npm install

# 3. Configure as variáveis de ambiente
cp .env.example .env
# Edite o .env com suas credenciais

# 4. Execute em desenvolvimento
npm run dev

# 5. Acesse http://localhost:5173
```

### Variáveis de Ambiente

Crie um arquivo `.env` na raiz do projeto:

```env
# Supabase
VITE_SUPABASE_URL=sua-url-supabase
VITE_SUPABASE_ANON_KEY=sua-chave-anon

# n8n Webhooks
VITE_N8N_WEBHOOK_URL=https://seu-n8n.com/webhook/atrIA
VITE_N8N_CREATE_ACCOUNT_WEBHOOK=https://seu-n8n.com/webhook/createaccount
```

---

## 📚 Documentação Completa

Para instruções detalhadas de instalação e configuração, consulte:

- **[Guia de Instalação Completo](GUIA_INSTALACAO_COMPLETO.md)** - Instalação passo a passo
- **[Documentação Técnica](DOCUMENTACAO_TECNICA.md)** - Arquitetura e detalhes técnicos
- **[Guia do Usuário](USER_GUIDE.md)** - Como usar o sistema
- **[Autenticação Supabase](SUPABASE_AUTH_EXPLICACAO.md)** - Detalhes sobre autenticação
- **[Guia de Testes](TESTING.md)** - Como testar o sistema

---

## 🏗️ Estrutura do Projeto

```
atria-chatbot/
├── src/
│   ├── components/          # Componentes React reutilizáveis
│   │   ├── AuthContext.tsx  # Contexto de autenticação
│   │   ├── ThemeContext.tsx # Gerenciamento de tema
│   │   ├── Sidebar.tsx      # Barra lateral de navegação
│   │   └── ...
│   ├── pages/               # Páginas da aplicação
│   │   ├── Login.tsx        # Página de login/registro
│   │   ├── Chat.tsx         # Interface principal do chat
│   │   ├── Admin.tsx        # Painel administrativo
│   │   └── AdminSettings.tsx # Configurações do sistema
│   ├── lib/                 # Bibliotecas e utilitários
│   │   ├── supabase.ts      # Cliente Supabase
│   │   ├── auth.ts          # Funções de autenticação
│   │   ├── db.ts            # Operações do banco
│   │   └── n8n.ts           # Integração n8n
│   └── types/               # Definições TypeScript
├── supabase/
│   ├── migrations/          # Migrações do banco de dados
│   └── functions/           # Edge Functions
│       ├── send-webhook/    # Envia mensagens para n8n
│       ├── receive-message/ # Recebe respostas do n8n
│       └── reset-admin-password/ # Reset de senha admin
└── ...
```

---

## 🔧 Scripts Disponíveis

```bash
# Desenvolvimento
npm run dev          # Inicia servidor de desenvolvimento

# Build
npm run build        # Cria build de produção
npm run preview      # Preview do build de produção

# Qualidade de Código
npm run typecheck    # Verifica tipos TypeScript
npm run lint         # Executa ESLint
```

---

## 🌐 Deploy

### Vercel (Recomendado)

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/SEU_USUARIO/atria-chatbot)

### Netlify

[![Deploy to Netlify](https://www.netlify.com/img/deploy/button.svg)](https://app.netlify.com/start/deploy?repository=https://github.com/SEU_USUARIO/atria-chatbot)

### GitHub Pages

```bash
npm install --save-dev gh-pages
npm run deploy
```

Veja o [Guia de Instalação Completo](GUIA_INSTALACAO_COMPLETO.md#deploy-automático-com-github) para instruções detalhadas.

---

## 🤝 Contribuindo

Contribuições são muito bem-vindas! Siga os passos abaixo:

1. **Fork o projeto**
2. **Crie uma branch** para sua feature (`git checkout -b feature/MinhaFeature`)
3. **Commit suas mudanças** (`git commit -m 'Adiciona: Minha nova feature'`)
4. **Push para a branch** (`git push origin feature/MinhaFeature`)
5. **Abra um Pull Request**

### Diretrizes de Contribuição

- Use mensagens de commit claras e descritivas
- Siga o padrão de código do projeto (ESLint + TypeScript)
- Adicione testes para novas funcionalidades
- Atualize a documentação conforme necessário
- Mantenha o código limpo e bem comentado

---

## 🐛 Reportar Bugs

Encontrou um bug? [Abra uma issue](https://github.com/SEU_USUARIO/atria-chatbot/issues/new) com:

- Descrição clara do problema
- Passos para reproduzir
- Comportamento esperado vs atual
- Screenshots (se aplicável)
- Informações do ambiente (navegador, SO, etc)

---

## 📝 Roadmap

Recursos planejados para futuras versões:

- [ ] Upload de arquivos no chat
- [ ] Suporte a áudio/voz
- [ ] Notificações push
- [ ] Exportação de conversas (PDF, CSV)
- [ ] Analytics e dashboard de métricas
- [ ] Integração com Microsoft Teams
- [ ] Integração com Slack
- [ ] API REST pública
- [ ] Modo offline
- [ ] Aplicativo mobile (React Native)

---

## 📄 Licença

Este projeto está sob a licença MIT. Veja o arquivo [LICENSE](LICENSE) para mais detalhes.

---

## 👥 Autores

**Desenvolvido com dedicação para Netwise**

- Sistema de chat e integração: [Netwise Team]
- Arquitetura e design: [Netwise Development]

---

## 🙏 Agradecimentos

- [Supabase](https://supabase.com/) - Backend as a Service incrível
- [n8n](https://n8n.io/) - Plataforma de automação poderosa
- [React](https://react.dev/) - Biblioteca UI fantástica
- [Tailwind CSS](https://tailwindcss.com/) - Framework CSS utility-first
- [Lucide](https://lucide.dev/) - Ícones SVG lindos

---

## 📞 Suporte

Precisa de ajuda? Entre em contato:

- 📧 Email: suporte@netwise.com.br
- 📖 Documentação: [Guia Completo](GUIA_INSTALACAO_COMPLETO.md)
- 🐛 Issues: [GitHub Issues](https://github.com/SEU_USUARIO/atria-chatbot/issues)

---

<div align="center">

**⭐ Se este projeto foi útil, considere dar uma estrela!**

Feito com ❤️ por [Netwise](https://netwise.com.br)

</div>
