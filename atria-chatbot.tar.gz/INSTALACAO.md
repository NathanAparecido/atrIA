# 📦 Guia de Instalação - AtrIA Chatbot

## 🎯 Visão Geral

Chatbot corporativo desenvolvido com React + TypeScript + Vite, integrado com Supabase para autenticação e banco de dados, e n8n para processamento de mensagens.

---

## 📋 Pré-requisitos

- **Node.js** (versão 18 ou superior)
- **npm** (vem com o Node.js)
- **Conta Supabase** (gratuita)
- **Servidor n8n** (para processamento de mensagens)

---

## 🚀 Instalação

### 1️⃣ Clone e Instale

```bash
git clone <URL_DO_REPOSITORIO>
cd <NOME_DO_PROJETO>
npm install
```

### 2️⃣ Configure o Arquivo `.env`

Crie um arquivo `.env` na raiz do projeto:

```env
VITE_SUPABASE_URL=https://ykaeqjzsgysqqkutbvpi.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InlrYWVxanpzZ3lzcXFrdXRidnBpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjIzNTc1MDgsImV4cCI6MjA3NzkzMzUwOH0.L9U8IyKMhi0Yg8AuudysXzt3blsgc5MTK6vpxB2yeBE

# n8n webhook URLs
VITE_N8N_WEBHOOK_URL=https://n8n.netwise.com.br/webhook/atrIA
VITE_N8N_CREATE_ACCOUNT_WEBHOOK=https://n8n.netwise.com.br/createaccount
```

**⚠️ IMPORTANTE:**
- Nunca comite o arquivo `.env` no Git
- Substitua as URLs pelos seus próprios valores de produção

---

## 🗄️ Configuração do Banco de Dados

### Aplicar Migrações

As migrações estão em `supabase/migrations/`. Se estiver começando do zero:

1. Acesse o Supabase Dashboard
2. Vá em "SQL Editor"
3. Execute os arquivos de migração na ordem numérica:
   - `20251105190634_create_initial_schema.sql`
   - `20251105205809_add_users_insert_policy.sql`
   - `20251110_create_sessions.sql`
   - `20251110132938_add_message_lookup_index.sql`
   - `20251202175814_20251202_fix_messages_update_policy.sql`
   - `20251202175834_20251202_fix_users_admin_policies.sql`
   - `20251202190425_20251202_add_user_profile_fields.sql`
   - `20251202191137_20251202_fix_users_admin_policies.sql`
   - `20251203204418_20251203_add_missing_admin_policies.sql`
   - `20251203_fix_function_search_path.sql` ⭐ **SEGURANÇA**

### Configurações de Segurança no Supabase

Após aplicar as migrações, configure as opções de segurança:

#### 1. Habilitar Proteção contra Senhas Vazadas

Esta funcionalidade verifica senhas contra o banco de dados HaveIBeenPwned.org:

1. Acesse o Supabase Dashboard
2. Vá em **Authentication** → **Policies**
3. Role até a seção **Security and Protection**
4. Encontre **"Leaked Password Protection"**
5. Clique em **"Enable"** ou marque a opção
6. Salve as alterações

**Por que é importante:**
- Bloqueia senhas que foram vazadas em ataques conhecidos
- Aumenta significativamente a segurança da aplicação
- Protege usuários que reutilizam senhas

#### 2. Verificar Correções de Segurança

As seguintes correções foram aplicadas automaticamente nas migrations:

✅ **Function Search Path** - Funções do banco agora usam `search_path` seguro
✅ **RLS Policies** - Todas as tabelas têm políticas restritivas
✅ **Admin Policies** - Políticas separadas para admins verificados

### Estrutura das Tabelas

**`users`** - Perfis de usuários
- `id`, `email`, `first_name`, `phone`, `department`, `role`, `created_at`

**`chat_sessions`** - Sessões de conversa
- `id`, `user_id`, `title`, `created_at`, `updated_at`

**`messages`** - Mensagens do chat
- `id`, `user_id`, `session_id`, `message`, `response`, `created_at`

**`audit_logs`** - Logs de auditoria
- `id`, `user_id`, `action`, `created_at`

---

## 🔧 Edge Functions (Opcional)

O projeto usa 3 Edge Functions no Supabase. Se precisar reimplantá-las:

### 1. `send-webhook`
Envia mensagens para o n8n.

**URL:** `https://ykaeqjzsgysqqkutbvpi.supabase.co/functions/v1/send-webhook`

### 2. `receive-message`
Recebe respostas do n8n e atualiza mensagens.

**URL:** `https://ykaeqjzsgysqqkutbvpi.supabase.co/functions/v1/receive-message`

### 3. `reset-admin-password`
Reseta senha de admin (apenas admins).

**URL:** `https://ykaeqjzsgysqqkutbvpi.supabase.co/functions/v1/reset-admin-password`

---

## 🎨 Executando o Projeto

### Desenvolvimento

```bash
npm run dev
```

Acesse: `http://localhost:5173`

### Produção

```bash
npm run build
npm run preview
```

### Verificações

```bash
npm run typecheck  # Verificar tipos TypeScript
npm run lint       # Linter
```

---

## 👥 Primeiro Acesso

### 1. Criar Conta

1. Acesse `/login`
2. Clique em "Cadastre-se"
3. Preencha:
   - Email
   - Primeiro Nome
   - Telefone (opcional)
   - Departamento
   - Senha (mínimo 6 caracteres)
4. Clique em "Cadastrar"

**O que acontece:**
- Conta criada no Supabase Auth (`auth.users`)
- Perfil salvo em `public.users`
- Webhook enviado para n8n (`VITE_N8N_CREATE_ACCOUNT_WEBHOOK`)
- Redirecionamento automático para o chat

### 2. Tornar Usuário Admin

1. Acesse o Supabase Dashboard
2. Vá em "Table Editor" → "users"
3. Encontre o usuário
4. Altere `role` de `user` para `admin`
5. Salve

**Funcionalidades Admin:**
- Painel `/admin` - visualizar todos os usuários
- Histórico de mensagens de todos os usuários
- Configurações do sistema em `/admin/settings`

---

## 🌐 Integração com n8n

### Fluxo de Mensagens

1. **Usuário envia mensagem** → Frontend chama Edge Function `send-webhook`
2. **Edge Function** → Envia para `VITE_N8N_WEBHOOK_URL`
3. **n8n processa** → Chama IA, processa resposta
4. **n8n retorna** → POST para `receive-message` Edge Function
5. **Edge Function atualiza** → Salva resposta no banco
6. **Frontend atualiza** → Exibe resposta em tempo real

### Payload: Envio de Mensagem

**Endpoint:** `https://n8n.netwise.com.br/webhook/atrIA`

```json
{
  "message": "Pergunta do usuário",
  "user_id": "uuid-do-usuario",
  "message_id": "uuid-da-mensagem",
  "session_id": "uuid-da-sessao",
  "callback_url": "https://ykaeqjzsgysqqkutbvpi.supabase.co/functions/v1/receive-message"
}
```

### Payload: Criação de Conta

**Endpoint:** `https://n8n.netwise.com.br/createaccount`

```json
{
  "email": "usuario@exemplo.com",
  "first_name": "Nome",
  "department": "n2",
  "phone": "+5511999999999",
  "created_at": "2024-12-03T00:00:00Z"
}
```

---

## 📁 Estrutura do Projeto

```
project/
├── src/
│   ├── components/          # Componentes reutilizáveis
│   │   ├── AuthContext.tsx  # Contexto de autenticação
│   │   ├── ThemeContext.tsx # Tema claro/escuro
│   │   ├── ToastContext.tsx # Notificações
│   │   ├── Sidebar.tsx      # Menu lateral
│   │   └── ...
│   ├── pages/               # Páginas
│   │   ├── Login.tsx        # Login/cadastro
│   │   ├── Chat.tsx         # Interface de chat
│   │   ├── Admin.tsx        # Painel admin
│   │   └── AdminSettings.tsx
│   ├── lib/                 # Utilitários
│   │   ├── supabase.ts      # Cliente Supabase
│   │   ├── auth.ts          # Autenticação
│   │   ├── db.ts            # Banco de dados
│   │   └── n8n.ts           # Integração n8n
│   ├── types/               # Tipos TypeScript
│   └── main.tsx
├── supabase/
│   ├── migrations/          # SQL migrations
│   └── functions/           # Edge Functions
├── .env                     # Variáveis (NÃO COMITAR!)
└── package.json
```

---

## 🐛 Troubleshooting

### Erro de Conexão Supabase

**Sintoma:** `Failed to fetch` ou erros de CORS

**Solução:**
- Verifique `.env` (URL e ANON_KEY corretos)
- Confirme que o projeto Supabase está ativo
- Verifique o console do navegador para detalhes

### Login Não Funciona

**Solução:**
1. Verifique se o email/senha estão corretos
2. Confirme que o usuário existe em `auth.users`
3. Verifique políticas RLS no Supabase

### Mensagens Não Aparecem

**Solução:**
1. Verifique se o webhook n8n está ativo e respondendo
2. Confirme que a Edge Function `receive-message` está implantada
3. Verifique logs no Supabase Dashboard → Edge Functions
4. Teste manualmente com curl/Postman

### Build Falha

**Solução:**
```bash
npm run typecheck  # Ver erros de tipo
npm run lint       # Ver problemas de código
rm -rf node_modules dist && npm install && npm run build
```

---

## 📚 Tecnologias

- **Frontend:** React 18, TypeScript, Vite, Tailwind CSS, React Router v7
- **UI:** Lucide React (ícones), Marked (markdown), DOMPurify (sanitização)
- **Backend:** Supabase (Auth, Database, Edge Functions), PostgreSQL
- **Integrações:** n8n (automações)

---

## 🔒 Segurança

✅ **Boas Práticas:**
- Nunca comite `.env`
- Use HTTPS em produção
- RLS habilitado em todas as tabelas
- Senhas gerenciadas pelo Supabase Auth
- Edge Functions com autenticação JWT (exceto webhooks públicos)

---

## 📞 Suporte

Consulte também:
- `DOCUMENTACAO_TECNICA.md` - Detalhes técnicos
- `USER_GUIDE.md` - Guia do usuário
- `TESTING.md` - Como testar

---

**Desenvolvido com ❤️ para Netwise**
